# برومبت بناء ZoomPro Camera (Infinix Hot 60i)

أنت مهندس Android أول. ابنِ مشروعاً كاملاً قابلاً للبناء باسم "ZoomPro Camera"، واكتب كل الملفات كاملة.

## الجهاز والقيود
- Infinix Hot 60i X6728: Helio G81 Ultimate، Android 15، كاميرا خلفية 50MP واحدة بدون OIS ولا تيليفوتو.
- minSdk 29، targetSdk 35، ABI: arm64-v8a. Kotlin + Compose (Material 3) + CameraX + Camera2 Interop + Hilt + Coroutines.
- اقرأ CameraCharacteristics وطبّق fallback لكل ميزة، ولا تفترض 4K ولا عدسات إضافية.
- هدف 30fps للمعاينة. أي معالجة ثقيلة (Super Resolution، دمج إطارات) تتم بعد الالتقاط على خيط خلفي.
- راقب الحرارة (ThermalStatus) وخفّض الجودة تلقائياً.

## الصلاحيات والتخزين
- CAMERA، RECORD_AUDIO (للفيديو)، READ_MEDIA_IMAGES/VIDEO (للمعرض)، ACCESS_COARSE/FINE_LOCATION (اختيارية)، INTERNET (اختيارية).
- بلا WRITE_EXTERNAL_STORAGE. الحفظ عبر MediaStore في Pictures/ZoomPro و Movies/ZoomPro.
- شاشة شرح قبل كل طلب صلاحية، وتعمل الميزات المتاحة عند الرفض.

## الميزات (بالمراحل)
1. كاميرا + زوم رقمي سلس (قرص زوم، Pinch، Tap-to-Focus) + فلاتر GLSL/LUT نهارية وليلية مع Slider للقوة.
2. وضع ليلي (دمج 4 إلى 8 إطارات + تقليل ضوضاء) + فيديو 1080p بالمدعوم فعلياً + EIS برمجي.
3. كشف كائنات (TFLite خفيف) + قياس مسافة وارتفاع بالسنتيمتر عبر ARCore، وبديل بزاوية الميل وجسم مرجعي. اعرض هامش الخطأ.
4. أوضاع: ماكرو، فلكي (تعريض طويل + خريطة سماء Offline)، تحت الماء (تصحيح ألوان)، حراري محاكى (مع تنبيه أنه محاكاة).
5. أدوات: Super Resolution بعد الالتقاط، OCR (عربي/إنجليزي)، QR، مقارنة قبل/بعد.

## التصميم
- داكن، تدرجات بنفسجي #7C4DFF وأزرق #00B0FF وسماوي #18FFFF، أزرار زجاجية، دعم RTL كامل (عربي/إنجليزي).
- أوضاع: صورة / فيديو / ليلي / احترافي / زوم.

## المخرجات
شجرة المشروع، كل ملفات Kotlin/XML/Gradle/Manifest/Shaders، تفعيل R8 وضغط الموارد، اختبارات أساسية، وتحقق أن `./gradlew assembleDebug` ينجح. الناتج: `app/build/outputs/apk/debug/`. حجم التطبيق المستهدف أقل من 80MB.
