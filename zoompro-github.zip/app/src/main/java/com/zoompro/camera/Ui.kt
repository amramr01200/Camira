package com.zoompro.camera

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// لوحة الألوان الذهبية (الأسماء PINK* أُبقيت كما هي في كل الملفات لتفادي تعديل كل مكان،
// والقيم فقط ذهبية الآن).
val PINK = Color(0xFFD4AF37)        // ذهبي أساسي
val PINK_LIGHT = Color(0xFFF6E7A8)  // ذهبي فاتح لامع
val PINK_DEEP = Color(0xFF8A6A1B)   // ذهبي داكن (برونزي)
val BG0 = Color(0xFF0A0804)
val BG1 = Color(0xFF1C1506)

val BRAND = Brush.horizontalGradient(listOf(PINK_DEEP, PINK, PINK_LIGHT))
private val SELECT = Brush.horizontalGradient(listOf(PINK, PINK_LIGHT))
private val SELECT_NIGHT = Brush.horizontalGradient(listOf(Color(0xFF5A1038), Color(0xFF8E1F5B)))

/** سطح زجاجي داكن بحد وردي رفيع. */
fun Modifier.glass(radius: Dp = 20.dp): Modifier {
    val s = RoundedCornerShape(radius)
    return this.clip(s)
        .background(Brush.verticalGradient(listOf(Color(0x66000000), Color(0x33000000))), s)
        .border(1.dp, Color(0x66FF4FA3), s)
}

@Composable
fun Chip(text: String, selected: Boolean = false, night: Boolean = false, compact: Boolean = false, onClick: () -> Unit) {
    val base = if (selected) {
        Modifier.clip(RoundedCornerShape(20.dp)).background(if (night) SELECT_NIGHT else SELECT)
    } else Modifier.glass()
    Text(
        text,
        color = if (selected && !night) Color.Black else PINK_LIGHT,
        fontSize = if (compact) 12.sp else 13.sp,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        modifier = base.clickable(onClick = onClick)
            .padding(horizontal = if (compact) 9.dp else 14.dp, vertical = 7.dp)
    )
}

/** زر عدسة دائري. soft = تكبير برمجي فوق حد العدسة. */
@Composable
fun LensChip(text: String, selected: Boolean, soft: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape)
            .background(
                if (selected) Brush.linearGradient(listOf(PINK_LIGHT, PINK))
                else Brush.linearGradient(listOf(Color(0x99000000), Color(0x99000000)))
            )
            .border(1.5.dp, if (soft) PINK_DEEP else PINK, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) Color.Black else PINK_LIGHT, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ShutterButton(busy: Boolean, recording: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.size(80.dp).alpha(if (busy) 0.45f else 1f)
            .border(4.dp, Brush.sweepGradient(listOf(PINK_DEEP, PINK_LIGHT, PINK, PINK_DEEP)), CircleShape)
            .padding(if (recording) 20.dp else 8.dp)
            .clip(RoundedCornerShape(if (recording) 8.dp else 40.dp))
            .background(
                if (recording) Brush.linearGradient(listOf(Color(0xFFFF3B30), Color(0xFFFF3B30)))
                else Brush.linearGradient(listOf(PINK_LIGHT, PINK))
            )
            .clickable(enabled = !busy, onClick = onClick)
    )
}
