package com.zoompro.camera

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.MutableFloatState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import kotlin.math.abs
import kotlin.math.atan2

/** زاوية ميل الهاتف الجانبية (Roll) بالدرجات، مع تنعيم، لاستخدامها في مستوى أفقي حي. */
@Composable
fun rememberRoll(active: Boolean): MutableFloatState {
    val ctx = LocalContext.current
    val roll = remember { mutableFloatStateOf(0f) }
    DisposableEffect(active) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val x = e.values[0]; val y = e.values[1]
                val deg = Math.toDegrees(atan2(x.toDouble(), y.toDouble())).toFloat()
                roll.floatValue += (deg - roll.floatValue) * 0.25f
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (active && sensor != null) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(l) }
    }
    return roll
}

/** مستوى أفقي (Bubble Level): خط مرجعي ثابت + خط يميل مع الهاتف، يتحول أخضر عند الاستواء. */
@Composable
fun LevelOverlay(roll: Float) {
    val isLevel = abs(roll) < 1.5f
    val color = if (isLevel) Color(0xFF34D17A) else PINK_LIGHT
    Canvas(Modifier.fillMaxSize()) {
        val c = center
        val halfW = size.width * 0.28f
        drawLine(Color(0x44FFFFFF), Offset(c.x - halfW, c.y), Offset(c.x + halfW, c.y), strokeWidth = 1.5f)
        rotate(degrees = -roll, pivot = c) {
            drawLine(color, Offset(c.x - halfW, c.y), Offset(c.x + halfW, c.y), strokeWidth = 4f)
        }
    }
}
