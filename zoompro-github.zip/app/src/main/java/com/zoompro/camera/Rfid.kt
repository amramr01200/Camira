package com.zoompro.camera

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.nfc.NfcAdapter
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.sqrt

private fun buzz(ctx: Context, ms: Long) {
    try {
        val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        v?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    } catch (e: Throwable) { }
}

private fun beep(ms: Int) {
    try {
        ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, ms)
    } catch (e: Throwable) { }
}

@Composable
private fun Card(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().glass(20.dp).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, color = PINK_LIGHT, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

@Composable
fun RfPanel(onExit: () -> Unit) {
    val ctx = LocalContext.current

    // ---- قارئ NFC ----
    var nfcMsg by remember { mutableStateOf("") }
    var tagInfo by remember { mutableStateOf("") }
    DisposableEffect(Unit) {
        val act = ctx as Activity
        val adapter = NfcAdapter.getDefaultAdapter(ctx)
        nfcMsg = when {
            adapter == null -> "هاتفك لا يدعم NFC."
            !adapter.isEnabled -> "NFC متوقف. فعّله من الإعدادات."
            else -> "قرّب البطاقة أو الوسم من ظهر الهاتف."
        }
        if (adapter != null && adapter.isEnabled) {
            adapter.enableReaderMode(
                act,
                NfcAdapter.ReaderCallback { tag ->
                    val uid = tag.id.joinToString(":") { "%02X".format(it) }
                    val techs = tag.techList.joinToString("، ") { it.substringAfterLast('.') }
                    tagInfo = "UID: $uid\nالتقنيات: $techs"
                },
                NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
                    NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V,
                null
            )
        }
        onDispose { if (adapter != null) runCatching { adapter.disableReaderMode(act) } }
    }

    // ---- فاحص المجال المغناطيسي ----
    val mag = remember { mutableStateListOf<Float>() }
    var magNow by remember { mutableFloatStateOf(0f) }
    var magMax by remember { mutableFloatStateOf(0f) }
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val s = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val v = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
                magNow = v
                if (v > magMax) magMax = v
                mag.add(v)
                if (mag.size > 120) mag.removeAt(0)
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (s != null) sm.registerListener(l, s, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(l) }
    }

    // ---- محاكاة الريموت ----
    var locked by remember { mutableStateOf(true) }
    var alarm by remember { mutableStateOf(false) }
    var floor by remember { mutableIntStateOf(0) }
    var target by remember { mutableIntStateOf(0) }
    LaunchedEffect(alarm) { while (alarm) { beep(300); buzz(ctx, 200); delay(600) } }
    LaunchedEffect(target) {
        while (floor != target) { delay(800); floor += if (target > floor) 1 else -1; buzz(ctx, 30) }
    }

    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(BG0, BG1)))
            .statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Chip("رجوع") { onExit() }
            Text("لوحة RF / RFID", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Card("قارئ NFC (بطاقات ووسوم)") {
            Text(nfcMsg, color = Color.White, fontSize = 14.sp)
            if (tagInfo.isNotEmpty()) Text(tagInfo, color = PINK_LIGHT, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Chip("إعدادات NFC") { ctx.startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) }
            Text(
                "يقرأ رقم التعريف (UID) ونوع التقنية فقط. الهواتف لا تقرأ الشريط المغناطيسي، ولا تنسخ بطاقات الدخول أو مفاتيح السيارات.",
                color = Color(0x99FFFFFF), fontSize = 11.sp
            )
        }

        Card("فاحص الإشارات المغناطيسية (حي)") {
            Text("${"%.1f".format(magNow)} µT", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("أعلى قراءة: ${"%.1f".format(magMax)} µT", color = Color(0xCCFFFFFF), fontSize = 12.sp)
            Canvas(Modifier.fillMaxWidth().height(90.dp).glass(12.dp)) {
                if (mag.size > 1) {
                    val top = max(100f, mag.maxOrNull() ?: 100f)
                    for (i in 1 until mag.size) {
                        drawLine(
                            PINK,
                            Offset((i - 1) * size.width / 119f, size.height - mag[i - 1] / top * size.height),
                            Offset(i * size.width / 119f, size.height - mag[i] / top * size.height),
                            3f
                        )
                    }
                }
            }
            val note = when {
                magNow > 120f -> "مصدر مغناطيسي أو معدن قوي قريب جداً."
                magNow > 70f -> "ارتفاع عن الطبيعي: مغناطيس أو إلكترونيات قريبة."
                else -> "ضمن المجال الأرضي الطبيعي (25 إلى 65 µT تقريباً)."
            }
            Text(note, color = Color.White, fontSize = 13.sp)
        }

        Card("محاكاة ريموت السيارة والمصعد") {
            Text(
                "محاكاة تعليمية فقط: لا تُرسل أي إشارة راديو ولا تتحكم بأي سيارة أو مصعد حقيقي.",
                color = Color(0xFFFFD6EA), fontSize = 12.sp
            )
            Text(
                (if (locked) "السيارة: مقفلة" else "السيارة: مفتوحة") + (if (alarm) "  |  الإنذار يعمل" else ""),
                color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("فتح", !locked) { locked = false; alarm = false; buzz(ctx, 60); beep(100) }
                Chip("غلق", locked) { locked = true; buzz(ctx, 60); beep(100); beep(100) }
                Chip("إنذار", alarm, true) { alarm = !alarm }
            }
            Text("المصعد", color = PINK_LIGHT, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text(
                "الطابق: $floor" + if (floor != target) "  (يتحرك إلى $target)" else "",
                color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (f in 0..5) Chip("$f", target == f, compact = true) { target = f }
            }
        }
    }
}
