package com.zoompro.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizerResult
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.max

// نموذج MediaPipe الرسمي (من خوادم Google نفسها) للتعرف على إشارات اليد.
// يُنزَّل مرة واحدة فقط عند أول استخدام (يحتاج إنترنت حينها)، ثم يُحفظ محلياً
// ويعمل بدون إنترنت بعد ذلك. هذا ليس نموذجاً من تأليفنا، بل أصل رسمي موثّق من Google.
private const val MODEL_URL =
    "https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/latest/gesture_recognizer.task"

private fun ensureGestureModel(ctx: Context, onReady: (File?) -> Unit) {
    val file = File(ctx.filesDir, "gesture_recognizer.task")
    if (file.exists() && file.length() > 0) { onReady(file); return }
    Executors.newSingleThreadExecutor().execute {
        try {
            val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 15000
            conn.connect()
            if (conn.responseCode != 200) { onReady(null); return@execute }
            conn.inputStream.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
            onReady(file)
        } catch (e: Throwable) {
            onReady(null)
        }
    }
}

private fun smallUprightBitmap(image: ImageProxy, maxSide: Int = 320): Bitmap {
    val raw = image.toBitmap()
    val rot = Matrix().apply { postRotate(image.imageInfo.rotationDegrees.toFloat()) }
    val up = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, rot, true)
    if (up !== raw) raw.recycle()
    val m = max(up.width, up.height)
    if (m <= maxSide) return up
    val k = maxSide.toFloat() / m
    val scaled = Bitmap.createScaledBitmap(up, (up.width * k).toInt(), (up.height * k).toInt(), true)
    up.recycle()
    return scaled
}

/**
 * يتعرّف على كف اليد المفتوحة ثم إغلاقها (قبضة) من الكاميرا الأمامية، ليُستخدم
 * كزناد التقاط عن بُعد. تشغيل فعلي حقيقي عبر نموذج Google الرسمي، وليس محاكاة.
 */
class HandGestureDetector(private val ctx: Context, private val onGesture: (String, Float) -> Unit) {
    private var recognizer: GestureRecognizer? = null
    @Volatile private var ready = false
    private var frameCount = 0

    fun start(onError: (String) -> Unit) {
        ensureGestureModel(ctx) { file ->
            if (file == null) {
                onError("يحتاج هذا أول مرة اتصالاً بالإنترنت لتنزيل نموذج التعرف على إشارة اليد.")
                return@ensureGestureModel
            }
            try {
                val base = BaseOptions.builder().setModelAssetPath(file.absolutePath).build()
                val options = GestureRecognizer.GestureRecognizerOptions.builder()
                    .setBaseOptions(base)
                    .setRunningMode(RunningMode.LIVE_STREAM)
                    .setResultListener { result, _ -> handleResult(result) }
                    .setErrorListener { onError("تعذر تشغيل التعرف على الإشارة: ${it.message}") }
                    .build()
                recognizer = GestureRecognizer.createFromOptions(ctx, options)
                ready = true
            } catch (e: Throwable) {
                onError("تعذر تحميل نموذج الإشارة: ${e.message}")
            }
        }
    }

    private fun handleResult(result: GestureRecognizerResult) {
        val top = result.gestures().firstOrNull()?.firstOrNull() ?: return
        onGesture(top.categoryName(), top.score())
    }

    /** يُستدعى من محلّل ImageAnalysis لكل إطار؛ نعالج إطاراً من كل 3 لتخفيف الحمل على المعالج. */
    fun analyze(image: ImageProxy) {
        frameCount++
        if (!ready || frameCount % 3 != 0) { image.close(); return }
        try {
            val bmp = smallUprightBitmap(image)
            val mpImage = BitmapImageBuilder(bmp).build()
            recognizer?.recognizeAsync(mpImage, SystemClock.uptimeMillis())
        } catch (e: Throwable) {
            // تجاهل إطاراً فشل مؤقتاً، لا نوقف البث
        } finally {
            image.close()
        }
    }

    fun close() {
        try { recognizer?.close() } catch (e: Throwable) { }
        recognizer = null
        ready = false
    }
}
