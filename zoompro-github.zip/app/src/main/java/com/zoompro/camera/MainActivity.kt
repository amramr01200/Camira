package com.zoompro.camera

import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.google.android.gms.ads.MobileAds

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        MobileAds.initialize(this) {} // تهيئة AdMob مرة واحدة عند فتح التطبيق
        setContent { CameraScreen() }
    }

    // بعض واجهات أندرويد المخصصة (مثل XOS) تعيد ضبط أعلام النافذة عند العودة
    // للتطبيق؛ نعيد التأكيد هنا حتى لا تُطفئ الشاشة نفسها أثناء الاستخدام.
    override fun onResume() {
        super.onResume()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // التقاط الصورة بزر رفع أو خفض الصوت بدل التحكم بمستوى الصوت نفسه،
    // طالما شاشة الكاميرا مفعّلة ومسجّلة في VolumeKeyBus.
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            val handled = VolumeKeyBus.onPress
            if (handled != null) {
                handled.invoke()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}
