package com.zoompro.camera

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * فلتران حقيقيان خارج نطاق مصفوفات الألوان العادية (كل الفلاتر السابقة لون واحد مسطّح).
 * هذان يُعالجان كل بكسل حسب سطوعه أو يمزجان طبقة ضوئية، ولهذا أثرهما الكامل يظهر في
 * الصورة المحفوظة فقط، بينما المعاينة الحية تعرض تقريباً بسيطاً له (قيد تقني: المعاينة
 * الحية تستخدم فلتر لوني سريع على الشاشة فقط، ولا تتحمل معالجة بكسل بكسل في كل إطار).
 */

private fun boxBlur(src: Bitmap, radius: Int): Bitmap {
    val w = src.width; val h = src.height
    val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
    val out = IntArray(w * h)
    for (y in 0 until h) {
        for (x in 0 until w) {
            var r = 0; var g = 0; var b = 0; var c = 0
            for (dy in -radius..radius) {
                val yy = (y + dy).coerceIn(0, h - 1)
                for (dx in -radius..radius) {
                    val xx = (x + dx).coerceIn(0, w - 1)
                    val p = px[yy * w + xx]
                    r += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255; c++
                }
            }
            out[y * w + x] = (0xFF shl 24) or ((r / c) shl 16) or ((g / c) shl 8) or (b / c)
        }
    }
    return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
}

/**
 * توهج حلمي (Bloom): طبقة مصغّرة ومموّهة ومُفتَّحة من الصورة نفسها تُمزج فوقها بوضع
 * "Screen"، فتضيء حول الإضاءات العالية بنعومة — تأثير حقيقي يُستخدم في السينما
 * والتصوير الاحترافي، وليس مجرد رفع سطوع عام.
 */
fun dreamGlow(src: Bitmap, strength: Float): Bitmap {
    if (strength <= 0.01f) return src
    val w = src.width; val h = src.height
    val smallW = (w / 6).coerceAtLeast(1); val smallH = (h / 6).coerceAtLeast(1)
    val small = Bitmap.createScaledBitmap(src, smallW, smallH, true)
    val blurred = boxBlur(small, 3)
    if (blurred !== small) small.recycle()
    val glow = Bitmap.createScaledBitmap(blurred, w, h, true)
    blurred.recycle()
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(out)
    canvas.drawBitmap(src, 0f, 0f, null)
    val paint = Paint().apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
        alpha = (190 * strength).roundToInt().coerceIn(0, 255)
    }
    canvas.drawBitmap(glow, 0f, 0f, paint)
    glow.recycle()
    return out
}

/**
 * تقسيم الألوان الاحترافي (Split Toning): يلوّن الظلال ببنفسجي عميق والإضاءات
 * بذهبي دافئ، كلٌّ حسب سطوع البكسل نفسه (وليس لوناً واحداً لكل الصورة). هذه تقنية
 * تصحيح ألوان سينمائية حقيقية يستخدمها مصححو الألوان الاحترافيون، لا فلتر بسيط.
 */
fun splitTone(src: Bitmap, strength: Float): Bitmap {
    if (strength <= 0.01f) return src
    val w = src.width; val h = src.height
    val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
    val out = IntArray(w * h)
    val shR = -18f; val shG = -6f; val shB = 22f   // الظلال: بنفسجي/أزرق عميق
    val hiR = 24f; val hiG = 10f; val hiB = -20f    // الإضاءات: ذهبي دافئ
    for (i in px.indices) {
        val p = px[i]
        val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
        val lum = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
        val shadowW = (1f - lum).coerceIn(0f, 1f)
        val highW = lum.coerceIn(0f, 1f)
        val nr = (r + (shR * shadowW + hiR * highW) * strength).roundToInt().coerceIn(0, 255)
        val ng = (g + (shG * shadowW + hiG * highW) * strength).roundToInt().coerceIn(0, 255)
        val nb = (b + (shB * shadowW + hiB * highW) * strength).roundToInt().coerceIn(0, 255)
        out[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
    }
    return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
}

/**
 * ازدواج لوني (Duotone): يستبدل كل الألوان بتدرّج بين لونين فقط حسب سطوع كل بكسل
 * (نيلي عميق في الظلال، ووردي-ذهبي في الإضاءات) — أسلوب ملصقات حديث شائع،
 * ومختلف تماماً عن تقسيم الألوان لأنه يُسقط اللون الأصلي كلياً بدل تعديله.
 */
fun duotone(src: Bitmap, strength: Float): Bitmap {
    if (strength <= 0.01f) return src
    val w = src.width; val h = src.height
    val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
    val out = IntArray(w * h)
    val shR = 30f; val shG = 20f; val shB = 70f
    val hiR = 255f; val hiG = 170f; val hiB = 110f
    for (i in px.indices) {
        val p = px[i]
        val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
        val lum = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
        val tr = shR + (hiR - shR) * lum
        val tg = shG + (hiG - shG) * lum
        val tb = shB + (hiB - shB) * lum
        val nr = (r + (tr - r) * strength).roundToInt().coerceIn(0, 255)
        val ng = (g + (tg - g) * strength).roundToInt().coerceIn(0, 255)
        val nb = (b + (tb - b) * strength).roundToInt().coerceIn(0, 255)
        out[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
    }
    return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
}

/**
 * فينييت سينمائي: تعتيم تدريجي حقيقي نحو زوايا الصورة (وليس إطاراً مرسوماً)،
 * يحسب المسافة الفعلية لكل بكسل عن المركز — تقنية تصوير كلاسيكية موعودة منذ البداية.
 */
fun vignette(src: Bitmap, strength: Float): Bitmap {
    if (strength <= 0.01f) return src
    val w = src.width; val h = src.height
    val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
    val out = IntArray(w * h)
    val cx = w / 2f; val cy = h / 2f
    val maxDist = sqrt(cx * cx + cy * cy)
    for (y in 0 until h) {
        for (x in 0 until w) {
            val i = y * w + x
            val p = px[i]
            val dx = x - cx; val dy = y - cy
            val distN = sqrt(dx * dx + dy * dy) / maxDist
            val f = (1f - (distN * distN) * 0.85f * strength).coerceIn(0.15f, 1f)
            val r = (((p shr 16) and 255) * f).roundToInt().coerceIn(0, 255)
            val g = (((p shr 8) and 255) * f).roundToInt().coerceIn(0, 255)
            val b = ((p and 255) * f).roundToInt().coerceIn(0, 255)
            out[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
    }
    return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
}
