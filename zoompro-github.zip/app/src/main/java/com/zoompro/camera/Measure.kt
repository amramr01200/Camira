package com.zoompro.camera

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.asin
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlin.math.tan

private fun buzz(ctx: Context, ms: Long) {
    try {
        val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        v?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    } catch (e: Throwable) { }
}

/** زاوية ميل الكاميرا تحت الأفق بالدرجات (موجب = لأسفل)، + هل القراءة مستقرة الآن. */
class TiltState(val angle: MutableFloatState, val stable: MutableState<Boolean>)

@Composable
fun rememberTilt(active: Boolean): TiltState {
    val ctx = LocalContext.current
    val tilt = remember { mutableFloatStateOf(0f) }
    val stable = remember { mutableStateOf(false) }
    val history = remember { ArrayDeque<Float>() }
    DisposableEffect(active) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val x = e.values[0]; val y = e.values[1]; val z = e.values[2]
                val g = sqrt(x * x + y * y + z * z)
                if (g < 1f) return
                val deg = Math.toDegrees(asin((z / g).coerceIn(-1f, 1f).toDouble())).toFloat()
                tilt.floatValue += (deg - tilt.floatValue) * 0.2f
                history.addLast(deg)
                if (history.size > 12) history.removeFirst()
                // "مستقر" = لم تختلف آخر 8 قراءات خام عن بعضها أكثر من 0.6 درجة،
                // أي أن يدك ثابتة فعلاً الآن وليس في منتصف حركة.
                stable.value = history.size >= 8 &&
                    ((history.maxOrNull() ?: 0f) - (history.minOrNull() ?: 0f)) < 0.6f
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (active && sensor != null) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm.unregisterListener(l); stable.value = false; history.clear() }
    }
    return TiltState(tilt, stable)
}

@Composable
fun MeasurePanel(
    tilt: Float, stable: Boolean, camH: Int, onCamH: (Int) -> Unit,
    onProgress: (kind: Int, step: Int, done: Boolean) -> Unit = { _, _, _ -> }
) {
    val ctx = LocalContext.current
    var kind by remember { mutableIntStateOf(0) }       // 0 مسافة، 1 ارتفاع، 2 معايرة
    var step by remember { mutableIntStateOf(0) }
    var knownD by remember { mutableIntStateOf(200) }
    var baseDist by remember { mutableFloatStateOf(0f) }
    var result by remember { mutableStateOf<String?>(null) }
    var wasStable by remember { mutableStateOf(false) }

    // اهتزاز خفيف واحد في لحظة استقرار اليد — إشارة لمسية بديلة عن مراقبة النص
    LaunchedEffect(stable) {
        if (stable && !wasStable) buzz(ctx, 20)
        wasStable = stable
    }

    // نُبلّغ الواجهة الخارجية بحالة التقدم (بداية/نهاية) لعرض شارتين فوق المعاينة،
    // بنفس فكرة النقطتين في وضع AR — بفارق مهم: هذه شارات حالة ثابتة المكان على
    // الشاشة (لا تتبّع فراغياً حقيقياً)، لأن وضع "بالميل" أصلاً لا يملك تتبعاً مكانياً.
    LaunchedEffect(kind, step, result) {
        onProgress(kind, step, result != null)
    }

    val liveDist: Float? =
        if (tilt > 3f) camH / tan(Math.toRadians(tilt.toDouble())).toFloat() else null

    fun reset() { step = 0; result = null }

    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).glass(24.dp).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("المسافة", kind == 0) { kind = 0; reset() }
            Chip("الارتفاع", kind == 1) { kind = 1; reset() }
            Chip("معايرة", kind == 2) { kind = 2; reset() }
        }
        if (kind < 2) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ارتفاع الهاتف", color = Color(0xCCFFFFFF), fontSize = 12.sp)
                Chip("-1") { onCamH((camH - 1).coerceAtLeast(30)); reset() }
                Text("$camH سم", color = PINK_LIGHT, fontWeight = FontWeight.Bold)
                Chip("+1") { onCamH((camH + 1).coerceAtMost(250)); reset() }
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المسافة المعروفة", color = Color(0xCCFFFFFF), fontSize = 12.sp)
                Chip("-10") { knownD = (knownD - 10).coerceAtLeast(50); reset() }
                Text("$knownD سم", color = PINK_LIGHT, fontWeight = FontWeight.Bold)
                Chip("+10") { knownD = (knownD + 10).coerceAtMost(500); reset() }
            }
        }

        // مؤشر ثبات اليد: يطلب منك الانتظار حتى يستقر قبل التثبيت، وهذا يرفع دقة
        // القراءة فعلياً (قراءة متذبذبة = خطأ أكبر في المسافة المحسوبة).
        if (result == null) {
            Text(
                if (stable) "اليد ثابتة ✅" else "ثبّت يدك قليلاً...",
                color = if (stable) Color(0xFF34D17A) else Color(0xFFFFC107),
                fontSize = 12.sp, fontWeight = FontWeight.Bold
            )
        }

        val msg = when {
            result != null -> result!!
            kind == 2 -> "ضع علامة على الأرض على بُعد $knownD سم أفقياً منك، ثم وجّه المركز نحوها"
            kind == 0 -> if (liveDist != null) "المسافة ≈ ${liveDist.toInt()} سم" else "وجّه المركز نحو الأرض عند قاعدة الجسم"
            step == 0 -> if (liveDist != null) "القاعدة على بُعد ≈ ${liveDist.toInt()} سم" else "وجّه المركز إلى قاعدة الجسم"
            else -> "الآن وجّه المركز إلى أعلى الجسم"
        }
        Text(
            msg, color = if (stable || result != null) Color.White else Color(0xBBFFFFFF),
            fontSize = 19.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (result != null) {
                Chip("قياس جديد", true) { reset() }
            } else if (kind == 2) {
                Chip(if (stable) "معايرة الآن" else "انتظر الثبات...", stable) {
                    if (stable && tilt > 5f) {
                        val h = (knownD * tan(Math.toRadians(tilt.toDouble()))).roundToInt().coerceIn(30, 250)
                        onCamH(h)
                        result = "تمت المعايرة: ارتفاع الهاتف = $h سم"
                        buzz(ctx, 40)
                    }
                }
            } else if (kind == 0) {
                Chip(if (stable) "تثبيت القياس" else "انتظر الثبات...", stable) {
                    if (stable && liveDist != null) {
                        result = "المسافة ≈ ${liveDist.toInt()} سم (${"%.2f".format(liveDist / 100f)} م)"
                        buzz(ctx, 40)
                    }
                }
            } else if (step == 0) {
                Chip(if (stable) "تثبيت القاعدة" else "انتظر الثبات...", stable) {
                    if (stable && liveDist != null) { baseDist = liveDist; step = 1; buzz(ctx, 25) }
                }
            } else {
                Chip(if (stable) "تثبيت القمة" else "انتظر الثبات...", stable) {
                    if (stable) {
                        val h = camH - baseDist * tan(Math.toRadians(tilt.toDouble())).toFloat()
                        result = "الارتفاع ≈ ${h.toInt()} سم (${"%.2f".format(h / 100f)} م)"
                        buzz(ctx, 40)
                    }
                }
            }
        }
        Text(
            "للدقة: عاير أولاً من تبويب «معايرة» (±2 إلى 4% بعدها). أمسك الهاتف رأسياً، وانتظر ظهور «اليد ثابتة» قبل التثبيت.",
            color = Color(0x99FFFFFF), fontSize = 11.sp, textAlign = TextAlign.Center
        )
    }
}
