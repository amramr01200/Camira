package com.zoompro.camera

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.exp
import kotlin.math.ln

/**
 * حلقة زوم لوغاريتمية: اسحب يميناً/يساراً لتحريك التدريج.
 * التدريج الذهبي الفاتح = عدسة فعلية، والداكن = تكبير برمجي.
 */
@Composable
fun LensRing(zoom: Float, maxZoom: Float, hwMax: Float, onZoom: (Float) -> Unit) {
    val z by rememberUpdatedState(zoom)
    val cb by rememberUpdatedState(onZoom)
    val paint = remember { Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER } }
    Canvas(
        Modifier.fillMaxWidth().height(46.dp).pointerInput(Unit) {
            val pxPerLn = 120.dp.toPx()
            detectHorizontalDragGestures { change, dx ->
                change.consume()
                cb(z * exp(-dx / pxPerLn))
            }
        }
    ) {
        val cx = size.width / 2f
        val pxPerLn = 120.dp.toPx()
        val lz = ln(zoom)
        val lmax = ln(maxZoom)
        val step = 0.05f
        var k = 0
        while (k * step <= lmax + 0.001f) {
            val l = k * step
            val x = cx + (l - lz) * pxPerLn
            if (x > -12f && x < size.width + 12f) {
                val soft = exp(l) > hwMax + 0.01f
                val major = k % 10 == 0
                val len = if (major) 20f else 11f
                drawLine(if (soft) PINK_DEEP else PINK, Offset(x, size.height - len), Offset(x, size.height), 2f)
            }
            k++
        }
        paint.textSize = 11.sp.toPx()
        listOf(1f, 2f, 3f, 5f, 10f, 20f, 30f).filter { it <= maxZoom }.forEach { p ->
            val x = cx + (ln(p) - lz) * pxPerLn
            if (x > 8f && x < size.width - 8f) {
                paint.color = (if (p > hwMax + 0.01f) PINK_DEEP else PINK_LIGHT).toArgb()
                drawIntoCanvas { it.nativeCanvas.drawText("${p.toInt()}x", x, size.height - 26f, paint) }
            }
        }
        drawLine(PINK_LIGHT, Offset(cx, 2f), Offset(cx, size.height * 0.55f), 3f)
    }
}
