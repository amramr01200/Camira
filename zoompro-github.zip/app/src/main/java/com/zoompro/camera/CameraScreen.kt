@file:OptIn(androidx.camera.camera2.interop.ExperimentalCamera2Interop::class)
// ملاحظة: تحكم الوضع الاحترافي والماكرو يعتمدان على نفس Camera2Interop المُستخدم
// أصلاً في الوضع الليلي (مُختبَر وناجح البناء سابقاً).

package com.zoompro.camera

import android.Manifest
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.View
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.UseCase
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private enum class Mode(val label: String) {
    PHOTO("صورة"), VIDEO("فيديو"), NIGHT("ليلي"), ASTRO("فلكي"), PRO("احترافي"), MACRO("ماكرو"),
    TRANSLATE("ترجمة"), AR("قياس AR"), MEASURE("بالميل"), RF("RFID")
}

private val previewSelector = ResolutionSelector.Builder()
    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
    .build()

// نلتقط بحوالي 12 ميجابكسل لتفادي نفاد الذاكرة عند المعالجة
private val captureSelector = ResolutionSelector.Builder()
    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
    .setResolutionStrategy(
        ResolutionStrategy(Size(4000, 3000), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
    ).build()

private fun toast(ctx: Context, msg: String) {
    Handler(Looper.getMainLooper()).post { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }
}

private fun stamp() = "ZoomPro_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

private fun newImageValues() = ContentValues().apply {
    put(MediaStore.Images.Media.DISPLAY_NAME, stamp())
    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ZoomPro")
}

private fun saveBitmap(ctx: Context, bmp: Bitmap) {
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, newImageValues())
        ?: error("MediaStore insert failed")
    ctx.contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
}

private fun applyMatrix(src: Bitmap, m: android.graphics.ColorMatrix): Bitmap {
    val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
    AndroidCanvas(out).drawBitmap(src, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(m) })
    return out
}

/**
 * تحكم يدوي حقيقي بحساس الكاميرا عبر Camera2Interop: يرفع ISO ويطيل زمن التعريض
 * فعلياً أثناء الالتقاط الليلي/الفلكي (وليس مجرد تفتيح الصورة بعد التقاطها)،
 * ثم يعيد الضبط التلقائي بعد الانتهاء. بعض الأجهزة لا تدعم هذا، فنتجاهل الخطأ بصمت.
 */
private fun applyManualNightExposure(cam: Camera, strong: Boolean, on: Boolean) {
    try {
        val control = Camera2CameraControl.from(cam.cameraControl)
        if (!on) {
            control.setCaptureRequestOptions(CaptureRequestOptions.Builder().build())
            return
        }
        val info = Camera2CameraInfo.from(cam.cameraInfo)
        val builder = CaptureRequestOptions.Builder()
            .setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
        val isoRange: android.util.Range<Int>? =
            info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        if (isoRange != null) {
            val iso = (if (strong) 3200 else 1200).coerceIn(isoRange.lower, isoRange.upper)
            builder.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, iso)
        }
        val expRange: android.util.Range<Long>? =
            info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        if (expRange != null) {
            // بالنانوثانية: ليلي ≈ 1/7 ثانية، فلكي ≈ 0.8 ثانية (يحتاج حاملاً ثابتاً)
            val wanted = if (strong) 800_000_000L else 140_000_000L
            builder.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, wanted.coerceIn(expRange.lower, expRange.upper))
        }
        control.setCaptureRequestOptions(builder.build())
    } catch (e: Throwable) {
        // التحكم اليدوي غير مدعوم على هذا الجهاز؛ نكمل بالوضع التلقائي العادي.
    }
}

private fun uprightBitmap(image: ImageProxy): Bitmap {
    val src = image.toBitmap()
    val rot = Matrix().apply { postRotate(image.imageInfo.rotationDegrees.toFloat()) }
    val up = Bitmap.createBitmap(src, 0, 0, src.width, src.height, rot, true)
    if (up !== src) src.recycle()
    return up
}

/**
 * يقلّص الصورة إن كانت أكبر من اللازم للمعالجة، لتفادي نفاد الذاكرة
 * (سبب شائع لإغلاق التطبيق فجأة أثناء تطبيق الفلتر أو الشحذ على صور كبيرة).
 */
private fun capForProcessing(src: Bitmap, maxSide: Int = 2600): Bitmap {
    val m = max(src.width, src.height)
    if (m <= maxSide) return src
    val k = maxSide.toFloat() / m
    val out = Bitmap.createScaledBitmap(src, (src.width * k).toInt(), (src.height * k).toInt(), true)
    src.recycle()
    return out
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 12.sp, modifier = Modifier.width(76.dp))
        Slider(
            value = value, onValueChange = onChange, valueRange = range, modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(
                thumbColor = PINK, activeTrackColor = PINK, inactiveTrackColor = Color(0x44FFFFFF))
        )
    }
}

@Composable
fun CameraScreen() {
    var screen by remember { mutableIntStateOf(0) }
    when (screen) {
        1 -> ArMeasureScreen { screen = 0 }
        2 -> RfPanel { screen = 0 }
        else -> CameraContent(onAr = { screen = 1 }, onRf = { screen = 2 })
    }
}

@Composable
private fun CameraContent(onAr: () -> Unit, onRf: () -> Unit) {
    val ctx = LocalContext.current
    val owner = ctx as LifecycleOwner
    val scope = rememberCoroutineScope()

    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }

    if (!granted) {
        Column(
            Modifier.fillMaxSize().background(BG0).padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("يحتاج التطبيق إلى إذن الكاميرا ليعمل.", color = Color.White, textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { launcher.launch(Manifest.permission.CAMERA) },
                colors = ButtonDefaults.buttonColors(containerColor = PINK, contentColor = Color.Black)
            ) { Text("منح الإذن") }
        }
        return
    }

    var audioGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val audioLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { audioGranted = it }

    val previewView = remember {
        PreviewView(ctx).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FIT_CENTER
        }
    }
    val executor = remember { Executors.newSingleThreadExecutor() }

    var mode by remember { mutableStateOf(Mode.PHOTO) }
    var lens by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var maxZoom by remember { mutableFloatStateOf(1f) }
    var hwMax by remember { mutableFloatStateOf(1f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var fIdx by remember { mutableIntStateOf(0) }
    var fGroup by remember { mutableIntStateOf(0) }
    var strength by remember { mutableFloatStateOf(1f) }
    var adjust by remember { mutableStateOf(Adjust()) }
    var expRange by remember { mutableStateOf(0..0) }
    var exp by remember { mutableFloatStateOf(0.5f) }
    var flash by remember { mutableStateOf(false) }
    var torch by remember { mutableStateOf(false) }
    var grid by remember { mutableStateOf(false) }
    var timer by remember { mutableIntStateOf(0) }
    var countdown by remember { mutableIntStateOf(0) }
    var panel by remember { mutableStateOf(false) }
    var ring by remember { mutableStateOf<Offset?>(null) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf("") }
    var camH by remember { mutableIntStateOf(130) }
    var ext by remember { mutableIntStateOf(ExtensionMode.NONE) }
    var extHdr by remember { mutableStateOf(false) }
    var extNight by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf<Recording?>(null) }
    var recSec by remember { mutableIntStateOf(0) }
    var translation by remember { mutableStateOf<String?>(null) }
    var handOn by remember { mutableStateOf(false) }
    var palmSeen by remember { mutableStateOf(false) }
    var handHint by remember { mutableStateOf("") }
    var gestureTrigger by remember { mutableIntStateOf(0) }
    var level by remember { mutableStateOf(false) }
    var extraClarity by remember { mutableStateOf(false) }
    var detectOn by remember { mutableStateOf(false) }
    var detBoxes by remember { mutableStateOf<List<DetBox>>(emptyList()) }
    var proIso by remember { mutableFloatStateOf(0.3f) }
    var proShutter by remember { mutableFloatStateOf(0.2f) }
    var proIsoText by remember { mutableStateOf("") }
    var proShutterText by remember { mutableStateOf("") }
    var measureKind by remember { mutableIntStateOf(0) }
    var measureStep by remember { mutableIntStateOf(0) }
    var measureDone by remember { mutableStateOf(false) }

    val isVideo = mode == Mode.VIDEO
    val tilt = rememberTilt(mode == Mode.MEASURE)
    val roll = rememberRoll(level)
    val capture = remember(lens) { ImageCapture.Builder().setResolutionSelector(captureSelector).build() }
    val detector = remember {
        HandGestureDetector(ctx) { name, score ->
            Handler(Looper.getMainLooper()).post {
                if (score < 0.6f) return@post
                when (name) {
                    "Open_Palm" -> { palmSeen = true; handHint = "جاهز، أغلق كفّك لالتقاط الصورة" }
                    "Closed_Fist" -> if (palmSeen) { palmSeen = false; handHint = ""; gestureTrigger++ }
                }
            }
        }
    }
    val handAnalysis = remember {
        ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            .also { it.setAnalyzer(executor) { img -> detector.analyze(img) } }
    }
    val liveDetector = remember {
        LiveDetector { boxes -> Handler(Looper.getMainLooper()).post { detBoxes = boxes } }
    }
    val detectAnalysis = remember {
        ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            .also { it.setAnalyzer(executor) { img -> liveDetector.analyze(img) } }
    }
    DisposableEffect(Unit) { onDispose { detector.close(); liveDetector.close() } }

    val videoCapture = remember {
        VideoCapture.withOutput(
            Recorder.Builder().setQualitySelector(
                QualitySelector.fromOrderedList(
                    listOf(Quality.FHD, Quality.HD, Quality.SD),
                    FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                )
            ).build()
        )
    }

    fun bindCamera(provider: ProcessCameraProvider, sel: CameraSelector, video: Boolean, hand: Boolean, detect: Boolean) {
        val preview = Preview.Builder().setResolutionSelector(previewSelector).build()
            .also { it.setSurfaceProvider(previewView.surfaceProvider) }
        provider.unbindAll()
        val useCases = ArrayList<UseCase>()
        useCases.add(preview)
        useCases.add(if (video) videoCapture else capture)
        if (hand) useCases.add(handAnalysis)
        if (detect) useCases.add(detectAnalysis)
        val cam = provider.bindToLifecycle(owner, sel, *useCases.toTypedArray())
        camera = cam
        hwMax = (cam.cameraInfo.zoomState.value?.maxZoomRatio ?: 1f).coerceAtLeast(1f)
        maxZoom = (hwMax * 3f).coerceAtMost(30f)   // ما فوق حد العتاد = تكبير برمجي (للصور فقط)
        zoom = 1f
        val r = cam.cameraInfo.exposureState.exposureCompensationRange
        expRange = r.lower..r.upper
        exp = 0.5f
    }

    DisposableEffect(lens, ext, isVideo, handOn, detectOn) {
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            try {
                val provider = future.get()
                val base = CameraSelector.Builder().requireLensFacing(lens).build()
                val extFuture = ExtensionsManager.getInstanceAsync(ctx, provider)
                extFuture.addListener({
                    try {
                        val mgr = extFuture.get()
                        extHdr = mgr.isExtensionAvailable(base, ExtensionMode.HDR)
                        extNight = mgr.isExtensionAvailable(base, ExtensionMode.NIGHT)
                        val useExt = !isVideo && ext != ExtensionMode.NONE && mgr.isExtensionAvailable(base, ext)
                        val sel = if (useExt) mgr.getExtensionEnabledCameraSelector(base, ext) else base
                        val wantHand = handOn && !isVideo && lens == CameraSelector.LENS_FACING_FRONT
                        val wantDetect = detectOn && !isVideo
                        try {
                            bindCamera(provider, sel, isVideo, wantHand, wantDetect)
                        } catch (e: Exception) {
                            if (useExt) { ext = ExtensionMode.NONE; toast(ctx, "الوضع الأصلي غير مدعوم هنا") }
                            else throw e
                        }
                    } catch (e: Exception) {
                        toast(ctx, "تعذر تشغيل الكاميرا: ${e.message}")
                    }
                }, ContextCompat.getMainExecutor(ctx))
            } catch (e: Exception) {
                toast(ctx, "تعذر تشغيل الكاميرا: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { if (future.isDone) runCatching { future.get().unbindAll() } }
    }

    fun zLimit() = if (mode == Mode.VIDEO) hwMax else maxZoom

    fun setZ(v: Float) {
        val z = v.coerceIn(1f, zLimit())
        zoom = z
        camera?.cameraControl?.setZoomRatio(minOf(z, hwMax))
    }

    fun setExp(f: Float) {
        exp = f
        val span = expRange.last - expRange.first
        if (span > 0) camera?.cameraControl?.setExposureCompensationIndex(expRange.first + (f * span).roundToInt())
    }

    fun pickFilter(name: String, force: Boolean) {
        val i = FILTERS.indexOfFirst { it.name == name }
        if (i >= 0 && (force || !FILTERS[fIdx].night)) {
            fIdx = i
            fGroup = FILTER_GROUPS.indexOf("ليلي")
        }
    }

    LaunchedEffect(mode, camera) {
        when (mode) {
            Mode.NIGHT -> { pickFilter("ليل صافٍ", false); setExp(0.85f) }
            Mode.ASTRO -> { pickFilter("نجوم", true); setExp(1f) }
            else -> setExp(0.5f)
        }
        if (mode == Mode.VIDEO) {
            if (zoom > hwMax) setZ(hwMax)
            if (!audioGranted) audioLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            recording?.stop()
            recording = null
        }
    }

    // الكشاف يعمل في كل الأوضاع (مهم للقياس والإضاءة الضعيفة)
    LaunchedEffect(torch, camera) { camera?.cameraControl?.enableTorch(torch) }

    // تحكم موحّد بإعدادات الكاميرا اليدوية حسب الوضع: احترافي (ISO/الغالق) أو
    // ماكرو (تركيز يدوي قريب)، وإلا تلقائي عادي. مصدر واحد يكتب هذه الإعدادات
    // لتفادي تعارض تأثيرات متعددة.
    LaunchedEffect(mode, camera, proIso, proShutter) {
        val cam = camera ?: return@LaunchedEffect
        try {
            val control = Camera2CameraControl.from(cam.cameraControl)
            val info = Camera2CameraInfo.from(cam.cameraInfo)
            when (mode) {
                Mode.PRO -> {
                    val b = CaptureRequestOptions.Builder()
                        .setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                    val isoR: android.util.Range<Int>? =
                        info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
                    if (isoR != null) {
                        val iso = (isoR.lower + (isoR.upper - isoR.lower) * proIso).roundToInt()
                            .coerceIn(isoR.lower, isoR.upper)
                        b.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, iso)
                        proIsoText = "ISO $iso"
                    }
                    val shR: android.util.Range<Long>? =
                        info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
                    if (shR != null && shR.lower > 0) {
                        val sh = (shR.lower.toDouble() * Math.pow(
                            shR.upper.toDouble() / shR.lower.toDouble(), proShutter.toDouble()
                        )).toLong().coerceIn(shR.lower, shR.upper)
                        b.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, sh)
                        val secs = sh / 1_000_000_000.0
                        proShutterText = if (secs < 1.0) "1/${(1.0 / secs).roundToInt()} ث" else "%.1f ث".format(secs)
                    }
                    control.setCaptureRequestOptions(b.build())
                }
                Mode.MACRO -> {
                    val minFocus: Float? =
                        info.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE)
                    if (minFocus != null && minFocus > 0f) {
                        control.setCaptureRequestOptions(
                            CaptureRequestOptions.Builder()
                                .setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                                .setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, minFocus)
                                .build()
                        )
                    } else {
                        toast(ctx, "جهازك بعدسة ثابتة التركيز؛ قرّب الجسم يدوياً قدر الإمكان")
                        control.setCaptureRequestOptions(CaptureRequestOptions.Builder().build())
                    }
                }
                else -> control.setCaptureRequestOptions(CaptureRequestOptions.Builder().build())
            }
        } catch (e: Throwable) {
            // التحكم اليدوي غير مدعوم على هذا الجهاز؛ نكمل بالوضع التلقائي العادي.
        }
    }
    LaunchedEffect(handOn, lens, mode) {
        val active = handOn && lens == CameraSelector.LENS_FACING_FRONT && mode == Mode.PHOTO
        if (active) {
            handHint = "جارٍ تجهيز التعرف على إشارة اليد..."
            detector.start { msg -> toast(ctx, msg); handOn = false }
        } else {
            detector.close()
            handHint = ""
            palmSeen = false
        }
    }
    LaunchedEffect(recording) {
        recSec = 0
        if (recording != null) { while (true) { delay(1000); recSec++ } }
    }
    LaunchedEffect(ring) { if (ring != null) { delay(900); ring = null } }

    fun shootPhoto() {
        capture.flashMode = if (flash) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
        val m = buildMatrix(FILTERS[fIdx], strength, adjust)
        val soft = max(1f, zoom / hwMax)
        busy = true
        if (m == null && soft <= 1.01f) {
            val opts = ImageCapture.OutputFileOptions.Builder(
                ctx.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, newImageValues()).build()
            capture.takePicture(opts, executor, object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) { busy = false; toast(ctx, "تم الحفظ") }
                override fun onError(e: ImageCaptureException) { busy = false; toast(ctx, "تعذر الحفظ: ${e.message}") }
            })
        } else {
            capture.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    try {
                        val rawUp = uprightBitmap(image)
                        val up = capForProcessing(rawUp)
                        val boostedBase = boostZoom(up, soft)
                        if (boostedBase !== up) up.recycle()
                        val boosted = if (extraClarity && soft > 1.01f)
                            sharpen(boostedBase, 0.35f).also { if (it !== boostedBase) boostedBase.recycle() }
                        else boostedBase
                        val colored = if (m != null) applyMatrix(boosted, m).also { boosted.recycle() } else boosted
                        val post = FILTERS[fIdx].post
                        val out = if (post != null) post(colored, strength).also { if (it !== colored) colored.recycle() } else colored
                        saveBitmap(ctx, out)
                        out.recycle()
                        toast(ctx, "تم الحفظ")
                    } catch (e: OutOfMemoryError) {
                        toast(ctx, "الذاكرة ممتلئة، جرّب بدون فلتر أو زوم أقل")
                    } catch (e: Throwable) {
                        toast(ctx, "تعذر الحفظ: ${e.message}")
                    } finally {
                        image.close()
                        busy = false
                    }
                }
                override fun onError(e: ImageCaptureException) { busy = false; toast(ctx, "تعذر الالتقاط: ${e.message}") }
            })
        }
    }

    fun finishStack(stacker: NightStacker, gamma: Float) {
        camera?.let { applyManualNightExposure(it, false, false) }
        try {
            val stackedRaw = stacker.result(gamma)
            val soft0 = max(1f, zoom / hwMax)
            val stackedBase = boostZoom(stackedRaw, soft0)
            if (stackedBase !== stackedRaw) stackedRaw.recycle()
            val stacked = if (extraClarity && soft0 > 1.01f)
                sharpen(stackedBase, 0.35f).also { if (it !== stackedBase) stackedBase.recycle() }
            else stackedBase
            val m = buildMatrix(FILTERS[fIdx], strength, adjust)
            val colored = if (m != null) applyMatrix(stacked, m).also { stacked.recycle() } else stacked
            val post = FILTERS[fIdx].post
            val out = if (post != null) post(colored, strength).also { if (it !== colored) colored.recycle() } else colored
            saveBitmap(ctx, out)
            out.recycle()
            toast(ctx, "تم حفظ الصورة")
        } catch (e: OutOfMemoryError) {
            toast(ctx, "الذاكرة ممتلئة، جرّب بعدد لقطات أقل")
        } catch (e: Throwable) {
            toast(ctx, "تعذر الحفظ: ${e.message}")
        } finally {
            busy = false
            progress = ""
        }
    }

    fun shootStack(total: Int, gamma: Float, strongIso: Boolean) {
        busy = true
        capture.flashMode = ImageCapture.FLASH_MODE_OFF
        camera?.let { applyManualNightExposure(it, strongIso, true) }
        val stacker = NightStacker()
        fun next(i: Int) {
            progress = "ثبّت الهاتف... $i/$total"
            capture.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    var ok = true
                    try {
                        val up = capForProcessing(uprightBitmap(image))
                        stacker.add(up)
                        up.recycle()
                    } catch (e: OutOfMemoryError) {
                        ok = false
                        toast(ctx, "الذاكرة ممتلئة أثناء الدمج الليلي")
                    } catch (e: Throwable) {
                        ok = false
                        toast(ctx, "تعذر المعالجة: ${e.message}")
                    } finally {
                        image.close()
                    }
                    if (!ok) { busy = false; progress = ""; return }
                    if (i < total) next(i + 1) else finishStack(stacker, gamma)
                }
                override fun onError(e: ImageCaptureException) {
                    busy = false; progress = ""; toast(ctx, "تعذر الالتقاط: ${e.message}")
                }
            })
        }
        next(1)
    }

    fun shootTranslate() {
        busy = true
        progress = "التقاط..."
        translation = null
        capture.flashMode = ImageCapture.FLASH_MODE_OFF
        capture.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                var bmp: Bitmap? = null
                try {
                    val up = uprightBitmap(image)
                    val k = min(1f, 2000f / max(up.width, up.height))
                    bmp = if (k < 1f) {
                        Bitmap.createScaledBitmap(up, (up.width * k).toInt(), (up.height * k).toInt(), true)
                            .also { up.recycle() }
                    } else up
                } catch (e: Throwable) {
                    toast(ctx, "تعذر المعالجة: ${e.message}")
                } finally {
                    image.close()
                }
                val b = bmp
                if (b == null) { busy = false; progress = ""; return }
                Handler(Looper.getMainLooper()).post {
                    translateToArabic(b, { progress = it }) { r ->
                        translation = r.text
                        progress = ""
                        val o = r.overlay
                        if (o != null) {
                            executor.execute {
                                try { saveBitmap(ctx, o); toast(ctx, "تم حفظ الصورة المترجمة") }
                                catch (e: Throwable) { toast(ctx, "تعذر الحفظ: ${e.message}") }
                                finally { o.recycle(); b.recycle(); busy = false }
                            }
                        } else {
                            b.recycle()
                            busy = false
                        }
                    }
                }
            }
            override fun onError(e: ImageCaptureException) {
                busy = false; progress = ""; toast(ctx, "تعذر الالتقاط: ${e.message}")
            }
        })
    }

    fun toggleRecording() {
        val r = recording
        if (r != null) { r.stop(); recording = null; return }
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, stamp())
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ZoomPro")
        }
        val opts = MediaStoreOutputOptions.Builder(ctx.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values).build()
        try {
            var pending = videoCapture.output.prepareRecording(ctx, opts)
            if (audioGranted) pending = pending.withAudioEnabled()
            recording = pending.start(ContextCompat.getMainExecutor(ctx)) { ev ->
                if (ev is VideoRecordEvent.Finalize) {
                    recording = null
                    toast(ctx, if (ev.hasError()) "تعذر حفظ الفيديو" else "تم حفظ الفيديو")
                }
            }
        } catch (e: Exception) {
            toast(ctx, "تعذر بدء التسجيل: ${e.message}")
        }
    }

    fun onShutter() {
        if (mode == Mode.VIDEO) { toggleRecording(); return }
        if (busy || countdown > 0) return
        scope.launch {
            if (timer > 0) {
                for (s in timer downTo 1) { countdown = s; delay(1000) }
                countdown = 0
            }
            when (mode) {
                Mode.NIGHT -> shootStack(6, 0.62f, false)
                Mode.ASTRO -> shootStack(12, 0.5f, true)
                Mode.TRANSLATE -> shootTranslate()
                else -> shootPhoto()
            }
        }
    }

    // عند اكتشاف إغلاق القبضة بعد كف مفتوح، نُطلق الالتقاط كما لو ضغط المستخدم الزر.
    LaunchedEffect(gestureTrigger) { if (gestureTrigger > 0) onShutter() }

    // التقاط بزر رفع/خفض الصوت بدل التحكم بمستوى الصوت، طالما هذه الشاشة ظاهرة.
    DisposableEffect(mode) {
        VolumeKeyBus.onPress = { if (mode != Mode.MEASURE) onShutter() }
        onDispose { VolumeKeyBus.onPress = null }
    }

    Column(Modifier.fillMaxSize().background(BG0).statusBarsPadding().navigationBarsPadding()) {
        // ---------- منظار الكاميرا (بلا إطار) ----------
        // ملاحظة: البانر الإعلاني يُرسم أسفل كل شيء (بعد لوحة التحكم)، فلا يغطي
        // المعاينة ولا زر الالتقاط إطلاقاً.
        Box(Modifier.fillMaxWidth().aspectRatio(3f / 4f)) {
            Box(Modifier.fillMaxSize().clipToBounds()) {
                AndroidView(
                    factory = { previewView },
                    modifier = Modifier.fillMaxSize().graphicsLayer {
                        val sc = max(1f, zoom / hwMax)
                        scaleX = sc
                        scaleY = sc
                    },
                    update = { v ->
                        val noFilter = mode == Mode.VIDEO || mode == Mode.TRANSLATE
                        val m = if (noFilter) null else buildMatrix(FILTERS[fIdx], strength, adjust)
                        val paint = m?.let { Paint().apply { colorFilter = ColorMatrixColorFilter(it) } }
                        v.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
                    }
                )
            }
            if (grid) {
                Canvas(Modifier.fillMaxSize()) {
                    val c = Color(0x66FFFFFF)
                    for (i in 1..2) {
                        drawLine(c, Offset(size.width * i / 3f, 0f), Offset(size.width * i / 3f, size.height), 2f)
                        drawLine(c, Offset(0f, size.height * i / 3f), Offset(size.width, size.height * i / 3f), 2f)
                    }
                }
            }
            if (level && mode != Mode.MEASURE) LevelOverlay(roll.floatValue)
            if (detectOn && zoom <= hwMax + 0.05f && detBoxes.isNotEmpty()) {
                Canvas(Modifier.fillMaxSize()) {
                    detBoxes.forEach { d ->
                        if (d.imgW > 0 && d.imgH > 0) {
                            val sx = size.width / d.imgW
                            val sy = size.height / d.imgH
                            val l = d.left * sx; val t = d.top * sy
                            val r = d.right * sx; val b = d.bottom * sy
                            drawRect(PINK_LIGHT, topLeft = Offset(l, t),
                                size = androidx.compose.ui.geometry.Size(r - l, b - t), style = Stroke(3f))
                        }
                    }
                }
            }
            if (mode == Mode.MEASURE) {
                // نفس لغة الألوان المستخدمة في قياس AR: أحمر أثناء انتظار ثبات اليد،
                // أخضر عندما تصبح القراءة مستقرة وجاهزة للتثبيت.
                val stableColor = if (tilt.stable.value) Color(0xFF34D17A) else Color(0xFFE53935)
                Canvas(Modifier.fillMaxSize()) {
                    val c = center
                    drawCircle(stableColor, 26f, c, style = Stroke(3f))
                    drawLine(stableColor, Offset(c.x - 70f, c.y), Offset(c.x + 70f, c.y), 3f)
                    drawLine(stableColor, Offset(c.x, c.y - 70f), Offset(c.x, c.y + 70f), 3f)
                }
                // شارتا "قاعدة" و"قمة": بخلاف قياس AR لا يوجد تتبّع فراغي هنا، فهما
                // شارتا حالة ثابتتا المكان على الشاشة (أعلى/أسفل)، وليستا نقطتين
                // مثبَّتتين في الواقع. تظهران فقط في وضع الارتفاع (ذو الخطوتين).
                if (measureKind == 1) {
                    Column(
                        Modifier.align(Alignment.Center).offset(y = (-120).dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            "● قمة", fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            color = if (measureDone) Color(0xFF34D17A) else Color(0xFFE53935)
                        )
                        Text(
                            "● قاعدة", fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            color = if (measureStep >= 1) Color(0xFF34D17A) else Color(0xFFE53935)
                        )
                    }
                }
            }
            Box(
                Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, _, g, _ -> if (g != 1f) setZ(zoom * g) }
                    }
                    .pointerInput(Unit) {
                        detectTapGestures { o ->
                            val sc = max(1f, zoom / hwMax)
                            val cx = size.width / 2f
                            val cy = size.height / 2f
                            val pt = previewView.meteringPointFactory.createPoint(cx + (o.x - cx) / sc, cy + (o.y - cy) / sc)
                            camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                            ring = o
                        }
                    }
            )
            ring?.let { p ->
                Box(
                    Modifier
                        .offset { IntOffset((p.x - 30.dp.toPx()).roundToInt(), (p.y - 30.dp.toPx()).roundToInt()) }
                        .size(60.dp).border(2.dp, PINK_LIGHT, CircleShape)
                )
            }
            if (countdown > 0) {
                Text("$countdown", color = Color.White, fontSize = 96.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Center))
            }
            if (handOn && handHint.isNotEmpty()) {
                Text(
                    handHint, color = PINK_LIGHT, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Center).padding(top = 140.dp)
                        .glass(14.dp).padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }
            if (progress.isNotEmpty()) {
                Text(progress, color = Color.White, fontSize = 14.sp,
                    modifier = Modifier.align(Alignment.Center).glass(14.dp).padding(horizontal = 14.dp, vertical = 6.dp))
            }

            // شريط التحكم العلوي
            Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                // شريط قابل للتمرير أفقياً (بدل Row ثابت) حتى لا يطفح عدد الأزرار
                // خارج عرض الشاشة ويُفسد التخطيط كما حدث عند إضافة أزرار جديدة.
                LazyRow(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    item { Chip("فلاش", flash, compact = true) { flash = !flash } }
                    item { Chip("كشاف", torch, compact = true) { torch = !torch } }
                    item { Chip("شبكة", grid, compact = true) { grid = !grid } }
                    item { Chip("مستوى", level, compact = true) { level = !level } }
                    item {
                        Chip(if (timer == 0) "مؤقت" else "${timer}ث", timer > 0, compact = true) {
                            timer = when (timer) { 0 -> 3; 3 -> 10; else -> 0 }
                        }
                    }
                    item {
                        Chip("قلب", compact = true) {
                            lens = if (lens == CameraSelector.LENS_FACING_BACK)
                                CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
                        }
                    }
                    if (lens == CameraSelector.LENS_FACING_FRONT && mode == Mode.PHOTO) {
                        item {
                            Chip(if (handOn) "تحكم باليد ✋" else "تحكم باليد", handOn, compact = true) { handOn = !handOn }
                        }
                    }
                    if (mode != Mode.VIDEO) {
                        item {
                            Chip(if (detectOn) "كشف الكائنات 👁" else "كشف الكائنات", detectOn, compact = true) { detectOn = !detectOn }
                        }
                    }
                }
                if (recording != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "● REC  %02d:%02d".format(recSec / 60, recSec % 60),
                        color = Color(0xFFFF3B30), fontWeight = FontWeight.Bold, fontSize = 15.sp,
                        modifier = Modifier.glass(12.dp).padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }

            // حلقة العدسة وأزرار الزوم
            if (!panel && mode != Mode.MEASURE && translation == null) {
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            "%.1fx".format(zoom) + if (zoom > hwMax + 0.05f) " (برمجي)" else "",
                            color = PINK_LIGHT, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.glass(12.dp).padding(horizontal = 12.dp, vertical = 3.dp)
                        )
                        if (zoom > hwMax + 0.05f && mode != Mode.VIDEO) {
                            Chip("وضوح إضافي", extraClarity, compact = true) { extraClarity = !extraClarity }
                        }
                    }
                    LensRing(zoom, zLimit(), hwMax) { setZ(it) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        listOf(1f, 2f, 3f, 5f, 10f, 20f, 30f).filter { it <= zLimit() }.forEach { z ->
                            LensChip("${z.toInt()}x", abs(zoom - z) < 0.05f, z > hwMax + 0.01f) { setZ(z) }
                        }
                        if (extHdr && !isVideo) Chip("HDR", ext == ExtensionMode.HDR, compact = true) {
                            ext = if (ext == ExtensionMode.HDR) ExtensionMode.NONE else ExtensionMode.HDR
                        }
                        if (extNight && !isVideo) Chip("ليل أصلي", ext == ExtensionMode.NIGHT, true, compact = true) {
                            ext = if (ext == ExtensionMode.NIGHT) ExtensionMode.NONE else ExtensionMode.NIGHT
                        }
                    }
                }
            }

            // نتيجة الترجمة
            val tr = translation
            if (tr != null) {
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().heightIn(max = 230.dp)
                        .background(Color(0xEE0B0508)).padding(12.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("الترجمة إلى العربية", color = PINK_LIGHT, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Chip("إغلاق", compact = true) { translation = null }
                    }
                    Text(tr, color = Color.White, fontSize = 16.sp,
                        modifier = Modifier.verticalScroll(rememberScrollState()).padding(top = 6.dp))
                }
            }

            if (panel) {
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .background(Color(0xDD0B0508)).padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    if (zLimit() > 1.01f) LabeledSlider("الزوم", zoom, 1f..zLimit()) { setZ(it) }
                    LabeledSlider("قوة الفلتر", strength, 0f..1f) { strength = it }
                    if (expRange.last > expRange.first) LabeledSlider("السطوع", exp, 0f..1f) { setExp(it) }
                    LabeledSlider("التباين", adjust.contrast, 0.6f..1.6f) { adjust = adjust.copy(contrast = it) }
                    LabeledSlider("التشبع", adjust.saturation, 0f..2f) { adjust = adjust.copy(saturation = it) }
                    LabeledSlider("الحرارة", adjust.warmth, -0.2f..0.2f) { adjust = adjust.copy(warmth = it) }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                        Chip("إعادة الضبط") { adjust = Adjust(); strength = 1f }
                    }
                }
            }
        }

        Spacer(Modifier.weight(1f))

        // ---------- جسم الكاميرا (لوحة التحكم) ----------
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF4A1230), Color(0xFF14070D))))
        ) {
            Box(Modifier.fillMaxWidth().height(10.dp)) {
                Box(
                    Modifier.align(Alignment.TopCenter).width(110.dp).height(6.dp)
                        .clip(RoundedCornerShape(bottomStart = 6.dp, bottomEnd = 6.dp)).background(BRAND)
                )
            }

            val showFilters = mode == Mode.PHOTO || mode == Mode.NIGHT || mode == Mode.ASTRO || mode == Mode.MACRO
            if (showFilters) {
                LazyRow(
                    Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(FILTER_GROUPS.size) { g ->
                        Text(
                            FILTER_GROUPS[g],
                            color = if (fGroup == g) PINK_LIGHT else Color(0x99FFFFFF),
                            fontWeight = if (fGroup == g) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp,
                            modifier = Modifier.clickable { fGroup = g }.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
                val groupFilters = remember(fGroup) { FILTERS.withIndex().filter { it.value.group == FILTER_GROUPS[fGroup] } }
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(groupFilters.size) { k ->
                        val iv = groupFilters[k]
                        Chip(iv.value.name, fIdx == iv.index, iv.value.night) { fIdx = iv.index }
                    }
                }
            }

            // قرص الأوضاع
            LazyRow(
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(Mode.values().size) { k ->
                    val m = Mode.values()[k]
                    val sel = mode == m
                    Text(
                        m.label,
                        color = if (sel) Color.Black else Color(0xCCFFFFFF),
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 14.sp,
                        modifier = Modifier.clip(RoundedCornerShape(16.dp))
                            .then(if (sel) Modifier.background(BRAND) else Modifier)
                            .clickable {
                                when (m) {
                                    Mode.AR -> onAr()
                                    Mode.RF -> onRf()
                                    else -> mode = m
                                }
                            }
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
            }

            if (mode == Mode.PRO) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).glass(20.dp).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("التحكم اليدوي بالحساس", color = PINK_LIGHT, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    LabeledSlider(if (proIsoText.isEmpty()) "ISO" else proIsoText, proIso, 0f..1f) { proIso = it }
                    LabeledSlider(if (proShutterText.isEmpty()) "الغالق" else proShutterText, proShutter, 0f..1f) { proShutter = it }
                    Text(
                        "القيم تقريبية وتعتمد على ما يدعمه حساس هاتفك فعلياً.",
                        color = Color(0x99FFFFFF), fontSize = 10.sp
                    )
                }
            }
            if (mode == Mode.MEASURE) {
                MeasurePanel(tilt.angle.floatValue, tilt.stable.value, camH, { camH = it }) { k, st, done ->
        measureKind = k; measureStep = st; measureDone = done
    }
                Spacer(Modifier.height(6.dp))
            } else {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Chip(if (panel) "إخفاء" else "ضبط", panel) { panel = !panel }
                    ShutterButton(busy, recording != null) { onShutter() }
                    Spacer(Modifier.width(64.dp))
                }
            }
        }

        // بانر إعلاني (AdMob) أسفل كل شيء؛ لا يغطي المعاينة ولا زر الالتقاط.
        AdBanner()
    }
}
