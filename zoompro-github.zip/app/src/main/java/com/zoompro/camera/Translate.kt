package com.zoompro.camera

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.text.StaticLayout
import android.text.TextPaint
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.max

class TranslateResult(val overlay: Bitmap?, val text: String)

// قارئ النصوص اللاتيني الافتراضي لا يقرأ الصينية أو اليابانية أو الكورية أو
// الهندية إطلاقاً (أبجديات مختلفة كلياً). لتغطية "كل اللغات" فعلياً، نُشغّل
// خمسة قارئات متخصصة معاً على نفس الصورة، ونختار نتيجة أكبرها نصاً (الأرجح
// مطابقتها للأبجدية الصحيحة الموجودة في الصورة).
private fun allRecognizers(): List<TextRecognizer> = listOf(
    TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS),
    TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()),
    TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()),
    TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()),
    TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build()),
)

/** يقرأ النص من الصورة (OCR بخمس أبجديات) ثم يترجمه إلى العربية ويرسمه فوق الصورة. */
fun translateToArabic(src: Bitmap, onProgress: (String) -> Unit, onDone: (TranslateResult) -> Unit) {
    onProgress("قراءة النص (كل الأبجديات)...")
    val input = InputImage.fromBitmap(src, 0)
    val clients = allRecognizers()
    var bestLen = -1
    var best: Text? = null
    var remaining = clients.size

    fun afterScan() {
        val vt = best
        if (vt == null) {
            onDone(TranslateResult(null, "لم أعثر على نص في الصورة. قرّب الورقة وحسّن الإضاءة."))
            return
        }
        continueWithText(src, vt, onProgress, onDone)
    }

    clients.forEach { client ->
        client.process(input)
            .addOnSuccessListener { vt ->
                if (vt.text.length > bestLen) { bestLen = vt.text.length; best = vt }
            }
            .addOnCompleteListener {
                client.close()
                remaining--
                if (remaining == 0) afterScan()
            }
    }
}

private fun continueWithText(
    src: Bitmap, vt: Text, onProgress: (String) -> Unit, onDone: (TranslateResult) -> Unit
) {
    val blocks = vt.textBlocks.filter { it.text.isNotBlank() && it.boundingBox != null }
    if (blocks.isEmpty()) {
        onDone(TranslateResult(null, "لم أعثر على نص في الصورة. قرّب الورقة وحسّن الإضاءة."))
        return
    }
    onProgress("تحديد اللغة...")
    LanguageIdentification.getClient().identifyLanguage(vt.text)
        .addOnFailureListener { onDone(TranslateResult(null, "تعذر تحديد اللغة: ${it.message}")) }
        .addOnSuccessListener { code ->
            val tag = if (code == "und") "en" else code
            val srcLang = TranslateLanguage.fromLanguageTag(tag)
            if (srcLang == null) {
                onDone(TranslateResult(null, "اللغة ($tag) غير مدعومة للترجمة."))
                return@addOnSuccessListener
            }
            if (srcLang == TranslateLanguage.ARABIC) {
                onDone(TranslateResult(null, "النص عربي أصلاً."))
                return@addOnSuccessListener
            }
            val translator = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(srcLang)
                    .setTargetLanguage(TranslateLanguage.ARABIC)
                    .build()
            )
            onProgress("تحميل نموذج الترجمة (أول مرة فقط، يلزم إنترنت)...")
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
                .addOnFailureListener {
                    translator.close()
                    onDone(TranslateResult(null, "تعذر تحميل نموذج الترجمة. اتصل بالإنترنت لأول مرة."))
                }
                .addOnSuccessListener {
                    val results = arrayOfNulls<String>(blocks.size)
                    fun step(i: Int) {
                        if (i >= blocks.size) {
                            translator.close()
                            finishOverlay(src, blocks, results, onDone)
                            return
                        }
                        onProgress("ترجمة ${i + 1}/${blocks.size}")
                        translator.translate(blocks[i].text)
                            .addOnSuccessListener { t -> results[i] = t; step(i + 1) }
                            .addOnFailureListener { results[i] = blocks[i].text; step(i + 1) }
                    }
                    step(0)
                }
        }
}

private fun finishOverlay(
    src: Bitmap, blocks: List<Text.TextBlock>, res: Array<String?>, onDone: (TranslateResult) -> Unit
) {
    val out = src.copy(Bitmap.Config.ARGB_8888, true)
    val canvas = Canvas(out)
    val bg = Paint().apply { color = Color.argb(235, 255, 255, 255) }
    val tp = TextPaint().apply { color = Color.BLACK; isAntiAlias = true }
    val sb = StringBuilder()
    blocks.forEachIndexed { i, b ->
        val r = b.boundingBox ?: return@forEachIndexed
        val t = res[i] ?: b.text
        sb.append(t).append("\n\n")
        canvas.drawRect(r, bg)
        val w = max(r.width(), 40)
        var size = r.height().coerceIn(14, 60).toFloat()
        tp.textSize = size
        var layout = StaticLayout.Builder.obtain(t, 0, t.length, tp, w).build()
        while (layout.height > r.height() && size > 12f) {
            size -= 2f
            tp.textSize = size
            layout = StaticLayout.Builder.obtain(t, 0, t.length, tp, w).build()
        }
        canvas.save()
        canvas.translate(r.left.toFloat(), r.top.toFloat())
        layout.draw(canvas)
        canvas.restore()
    }
    onDone(TranslateResult(out, sb.toString().trim()))
}
