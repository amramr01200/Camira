package com.zoompro.camera

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

// معرّف إعلان Google الرسمي للاختبار (Test Ad Unit)، موثّق علنياً وآمن للتجربة.
// ⚠️ استبدله بمعرّف وحدة الإعلان الحقيقي من حسابك في AdMob قبل نشر التطبيق،
// وإلا ستظهر إعلانات اختبار فقط ولن تُحقق أي عائد، وقد يُعلَّق حسابك إن نشرته هكذا.
private const val BANNER_AD_UNIT_ID = "ca-app-pub-6472253108184229/2209245729"

/** بانر إعلاني رفيع (AdMob) يُعاد تحميله تلقائياً، بإدارة دورة حياة صحيحة. */
@Composable
fun AdBanner(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val adView = remember {
        AdView(ctx).apply {
            setAdSize(AdSize.BANNER)
            adUnitId = BANNER_AD_UNIT_ID
            loadAd(AdRequest.Builder().build())
        }
    }
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> adView.resume()
                Lifecycle.Event.ON_PAUSE -> adView.pause()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(obs)
            adView.destroy()
        }
    }
    AndroidView(factory = { adView }, modifier = modifier.fillMaxWidth())
}
