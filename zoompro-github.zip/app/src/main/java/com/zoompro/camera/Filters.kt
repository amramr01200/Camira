package com.zoompro.camera

import android.graphics.Bitmap
import android.graphics.ColorMatrix

data class CamFilter(
    val name: String,
    val group: String,
    val night: Boolean,
    val matrix: ColorMatrix?,
    // معالجة إضافية حقيقية (غير مصفوفة ألوان) تُطبَّق على الصورة المحفوظة فقط،
    // مثل التوهج أو تقسيم الألوان، لأنها أثقل من أن تعمل على المعاينة الحية.
    val post: ((Bitmap, Float) -> Bitmap)? = null
)

data class Adjust(val contrast: Float = 1f, val saturation: Float = 1f, val warmth: Float = 0f) {
    val isDefault get() = contrast == 1f && saturation == 1f && warmth == 0f
}

internal fun sat(s: Float) = ColorMatrix().apply { setSaturation(s) }

internal fun bc(b: Float, c: Float): ColorMatrix {
    val t = (1f - c) * 128f + b
    return ColorMatrix(floatArrayOf(
        c, 0f, 0f, 0f, t,
        0f, c, 0f, 0f, t,
        0f, 0f, c, 0f, t,
        0f, 0f, 0f, 1f, 0f))
}

internal fun tint(r: Float, g: Float, b: Float) = ColorMatrix(floatArrayOf(
    r, 0f, 0f, 0f, 0f,
    0f, g, 0f, 0f, 0f,
    0f, 0f, b, 0f, 0f,
    0f, 0f, 0f, 1f, 0f))

internal fun mix(vararg m: ColorMatrix) = ColorMatrix().apply { m.forEach { postConcat(it) } }

private val nightVision = ColorMatrix(floatArrayOf(
    0f, 0f, 0f, 0f, 0f,
    0.45f, 0.9f, 0.17f, 0f, 35f,
    0f, 0f, 0f, 0f, 0f,
    0f, 0f, 0f, 1f, 0f))

// فسفور أخضر كثيف (طراز نظارات الرؤية الليلية العسكرية)
private val phosphorGreen = ColorMatrix(floatArrayOf(
    0f, 0f, 0f, 0f, 0f,
    0.3f, 1.1f, 0.3f, 0f, 20f,
    0f, 0f, 0f, 0f, 0f,
    0f, 0f, 0f, 1f, 0f))

// كهرمان دافئ (طراز الرؤية الليلية الحديثة منخفضة الإجهاد البصري)
private val amberVision = ColorMatrix(floatArrayOf(
    0.75f, 0.2f, 0f, 0f, 30f,
    0.45f, 0.5f, 0f, 0f, 20f,
    0f, 0f, 0.15f, 0f, 0f,
    0f, 0f, 0f, 1f, 0f))

// أزرق بنفسجي باهت لمحاكاة تضخيم ضوء النجوم (Starlight)
private val starlightBlue = mix(
    ColorMatrix(floatArrayOf(
        0.55f, 0f, 0.15f, 0f, 10f,
        0.1f, 0.6f, 0.1f, 0f, 10f,
        0.15f, 0.05f, 0.85f, 0f, 25f,
        0f, 0f, 0f, 1f, 0f)),
    bc(15f, 1.2f)
)

// دمج ليلي عالي التباين (يحاكي تراكب عدة تعريضات لإبراز التفاصيل الخفية)
private val nightFusion = mix(bc(28f, 1.35f), sat(1.15f), tint(0.97f, 1f, 1.05f))

// رمادي فضي بارد لذيذ للمشاهد القمرية شبه المعتمة
private val silverMoon = mix(sat(0.3f), tint(0.95f, 1f, 1.08f), bc(22f, 1.1f))

// تباين حراري بارد (محاكاة ألوان زائفة فقط وليست قياساً حرارياً حقيقياً)
private val thermalSim = ColorMatrix(floatArrayOf(
    1.3f, 0.4f, -0.3f, 0f, -20f,
    -0.2f, 0.9f, 0.3f, 0f, 10f,
    -0.4f, -0.3f, 1.2f, 0f, 30f,
    0f, 0f, 0f, 1f, 0f))

private val sepia = ColorMatrix(floatArrayOf(
    0.393f, 0.769f, 0.189f, 0f, 0f,
    0.349f, 0.686f, 0.168f, 0f, 0f,
    0.272f, 0.534f, 0.131f, 0f, 0f,
    0f, 0f, 0f, 1f, 0f))

val FILTER_GROUPS = listOf("أساسي", "أفلام", "سينما", "بورتريه", "ألوان", "أبيض وأسود", "وردي", "ليلي", "إبداعي", "مبتكر")

private fun f(g: String, n: String, m: ColorMatrix?, night: Boolean = false) = CamFilter(n, g, night, m)
private fun f2(g: String, n: String, m: ColorMatrix?, post: (Bitmap, Float) -> Bitmap) = CamFilter(n, g, false, m, post)

val FILTERS = listOf(
    f("أساسي", "طبيعي", null),
    f("أساسي", "حيوي", mix(sat(1.4f), bc(0f, 1.1f))),
    f("أساسي", "نقي", mix(bc(6f, 1.08f), sat(1.12f))),
    f("أساسي", "أوضح", mix(bc(-2f, 1.18f), sat(1.1f))),
    f("أساسي", "HDR بوب", mix(bc(-4f, 1.3f), sat(1.35f))),

    f("أفلام", "بورترا", mix(tint(1.05f, 1f, 0.95f), sat(0.95f), bc(10f, 0.96f))),
    f("أفلام", "كوداك غولد", mix(tint(1.12f, 1.02f, 0.82f), sat(1.2f), bc(6f, 1.05f))),
    f("أفلام", "فوجي", mix(tint(0.96f, 1.04f, 1f), sat(1.15f), bc(0f, 1.1f))),
    f("أفلام", "كوداكروم", mix(tint(1.08f, 0.98f, 0.9f), sat(1.35f), bc(-4f, 1.2f))),
    f("أفلام", "بولارويد", mix(tint(1.05f, 1f, 0.92f), sat(0.9f), bc(20f, 0.88f))),
    f("أفلام", "فينتج 70", mix(sat(0.65f), tint(1.1f, 1f, 0.82f), bc(12f, 0.9f))),
    f("أفلام", "كروس بروسس", mix(tint(1.1f, 0.95f, 1.15f), sat(1.3f), bc(0f, 1.2f))),
    f("أفلام", "بلييتش", mix(sat(0.5f), bc(-6f, 1.35f))),

    f("سينما", "سينمائي", mix(sat(0.85f), bc(-6f, 1.2f), tint(1.04f, 1f, 0.96f))),
    f("سينما", "تيل سينمائي", mix(tint(0.9f, 1.02f, 1.1f), sat(1.1f), bc(-3f, 1.15f))),
    f("سينما", "برتقالي دافئ", mix(tint(1.08f, 1f, 0.94f), sat(1.25f), bc(-3f, 1.15f))),
    f("سينما", "دراما", mix(sat(0.8f), bc(-10f, 1.3f))),
    f("سينما", "مات", mix(bc(22f, 0.82f), sat(0.85f))),
    f("سينما", "نوار", mix(sat(0f), bc(-8f, 1.4f))),
    f("سينما", "سايبربانك", mix(tint(1.1f, 0.9f, 1.25f), sat(1.6f), bc(0f, 1.2f))),

    f("بورتريه", "توهج البورتريه", mix(tint(1.06f, 1f, 0.97f), bc(12f, 0.95f), sat(1.05f))),
    f("بورتريه", "بشرة ناعمة", mix(tint(1.05f, 1f, 0.98f), bc(10f, 0.94f), sat(1.05f))),
    f("بورتريه", "دافئ ناعم", mix(tint(1.08f, 1f, 0.9f), sat(1.1f), bc(8f, 0.98f))),
    f("بورتريه", "ساطع", mix(bc(18f, 1.05f), sat(1.1f))),
    f("بورتريه", "وجه مشرق", mix(tint(1.04f, 1.02f, 1f), bc(16f, 0.98f), sat(1.08f))),

    f("ألوان", "دافئ", mix(tint(1.1f, 1f, 0.88f), sat(1.1f))),
    f("ألوان", "بارد", tint(0.9f, 1f, 1.12f)),
    f("ألوان", "زاهي", mix(sat(1.6f), bc(0f, 1.08f))),
    f("ألوان", "بحري", mix(tint(0.92f, 1.02f, 1.12f), sat(1.25f))),
    f("ألوان", "غابة", mix(tint(0.95f, 1.08f, 0.92f), sat(1.3f))),
    f("ألوان", "غروب", mix(tint(1.2f, 1f, 0.8f), sat(1.3f), bc(0f, 1.1f))),
    f("ألوان", "شتوي", mix(tint(0.9f, 0.98f, 1.12f), bc(8f, 1.05f))),

    f("أبيض وأسود", "أبيض وأسود", mix(sat(0f), bc(0f, 1.15f))),
    f("أبيض وأسود", "تباين عالٍ", mix(sat(0f), bc(0f, 1.5f))),
    f("أبيض وأسود", "ناعم", mix(sat(0f), bc(12f, 0.9f))),
    f("أبيض وأسود", "سيبيا", sepia),

    f("وردي", "وردي ناعم", mix(tint(1.1f, 0.97f, 1.04f), sat(1.1f), bc(10f, 0.96f))),
    f("وردي", "كاندي", mix(tint(1.12f, 0.96f, 1.08f), sat(1.5f), bc(8f, 1f))),
    f("وردي", "روز غولد", mix(tint(1.14f, 1f, 0.92f), sat(1.1f), bc(8f, 1.04f))),
    f("وردي", "وردي سينمائي", mix(tint(1.08f, 0.94f, 1.06f), sat(0.95f), bc(-2f, 1.15f))),
    f("وردي", "غروب وردي", mix(tint(1.2f, 0.95f, 1f), sat(1.3f), bc(5f, 1.05f))),

    f("ليلي", "ليل صافٍ", mix(bc(35f, 1.15f), sat(1.1f)), true),
    f("ليلي", "رؤية ليلية", nightVision, true),
    f("ليلي", "تعزيز الضوء", bc(55f, 1.25f), true),
    f("ليلي", "ضوء القمر", mix(tint(0.88f, 0.98f, 1.15f), bc(25f, 1.1f), sat(0.85f)), true),
    f("ليلي", "نيون", mix(sat(1.8f), bc(10f, 1.25f)), true),
    f("ليلي", "نجوم", mix(bc(30f, 1.3f), tint(0.92f, 0.98f, 1.1f), sat(1.1f)), true),
    f("ليلي", "ليل دافئ", mix(bc(40f, 1.15f), tint(1.1f, 1f, 0.88f)), true),
    f("ليلي", "مدينة ليلية", mix(bc(30f, 1.2f), sat(1.4f), tint(1.05f, 1f, 1.1f)), true),
    f("ليلي", "رؤية ليلية أبيض وأسود", mix(sat(0f), bc(45f, 1.2f)), true),
    f("ليلي", "رؤية ليلية تباين عالٍ", mix(sat(0f), bc(25f, 1.6f)), true),
    f("ليلي", "فسفور أخضر", phosphorGreen, true),
    f("ليلي", "كهرمان مريح", amberVision, true),
    f("ليلي", "تضخيم النجوم", starlightBlue, true),
    f("ليلي", "دمج ليلي HDR", nightFusion, true),
    f("ليلي", "قمر فضي", silverMoon, true),
    f("ليلي", "محاكاة حرارية", thermalSim, true),

    f("إبداعي", "تيل وبرتقالي", mix(tint(1.1f, 1f, 0.8f), sat(1.3f), bc(-6f, 1.2f))),
    f("إبداعي", "ساعة ذهبية", mix(tint(1.18f, 1.02f, 0.78f), sat(1.2f), bc(4f, 1.08f))),
    f("إبداعي", "قطبي بارد", mix(tint(0.85f, 0.98f, 1.15f), sat(0.9f), bc(10f, 1.1f))),
    f("إبداعي", "رمال ذهبية", mix(tint(1.15f, 1.04f, 0.78f), sat(1.15f))),
    f("إبداعي", "تصحيح تحت الماء", mix(tint(1.35f, 1f, 0.9f), sat(1.2f), bc(8f, 1.05f))),
    f("إبداعي", "أشعة تحت حمراء", mix(sat(0.2f), tint(1.3f, 0.9f, 0.9f), bc(20f, 1.2f))),

    // فلتران حقيقيان بمعالجة بكسل-ببكسل (وليسا مجرد لون مسطّح)؛ أثرهما الكامل
    // يظهر في الصورة المحفوظة، والمعاينة الحية تعرض تقريباً بسيطاً فقط.
    f2("مبتكر", "توهج الحلم", mix(bc(6f, 1.05f), sat(1.08f)), ::dreamGlow),
    f2("مبتكر", "تقسيم الألوان الاحترافي", mix(bc(0f, 1.08f)), ::splitTone),
    f2("مبتكر", "ازدواج لوني", mix(tint(1.05f, 0.95f, 1.1f)), ::duotone),
    f2("مبتكر", "فينييت سينمائي", mix(bc(-4f, 1.1f)), ::vignette),
)

fun CamFilter.blended(strength: Float): ColorMatrix? {
    val m = matrix ?: return null
    val a = m.array
    val out = FloatArray(20) { i ->
        val id = if (i == 0 || i == 6 || i == 12 || i == 18) 1f else 0f
        id + (a[i] - id) * strength
    }
    return ColorMatrix(out)
}

fun buildMatrix(f: CamFilter, strength: Float, a: Adjust): ColorMatrix? {
    val base = f.blended(strength)
    if (base == null && a.isDefault) return null
    val m = base ?: ColorMatrix()
    if (!a.isDefault) {
        m.postConcat(bc(0f, a.contrast))
        m.postConcat(sat(a.saturation))
        m.postConcat(tint(1f + a.warmth, 1f, 1f - a.warmth))
    }
    return m
}
