package com.zoompro.camera

/** جسر بسيط بين زري الصوت في النشاط (Activity) وشاشة الكاميرا داخل Compose. */
object VolumeKeyBus {
    var onPress: (() -> Unit)? = null
}
