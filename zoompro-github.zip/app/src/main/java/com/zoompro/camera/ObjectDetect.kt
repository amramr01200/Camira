package com.zoompro.camera

import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.ObjectDetector
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions

/** مربّع كائن مكتشَف بإحداثيات صورة التحليل (iw×ih)، وليس إحداثيات الشاشة مباشرة. */
data class DetBox(val left: Float, val top: Float, val right: Float, val bottom: Float, val label: String, val imgW: Int, val imgH: Int)

private fun arabicLabel(text: String?): String = when (text) {
    "Fashion good" -> "ملابس/إكسسوار"
    "Food" -> "طعام"
    "Home good" -> "أداة منزلية"
    "Place" -> "مكان"
    "Plant" -> "نبات"
    else -> "جسم"
}

/**
 * كشف كائنات حي بدون إنترنت: وجوه (تُعرض كـ"شخص") عبر ML Kit Face Detection،
 * وكائنات عامة عبر ML Kit Object Detection (5 فئات واسعة فقط: ملابس/طعام/أداة
 * منزلية/مكان/نبات — وليس تصنيف أنواع حيوانات دقيقاً، فهذا يحتاج نموذجاً مخصصاً
 * غير متوفر هنا).
 */
class LiveDetector(private val onBoxes: (List<DetBox>) -> Unit) {
    private val objectDetector: ObjectDetector = ObjectDetection.getClient(
        ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
            .enableMultipleObjects()
            .enableClassification()
            .build()
    )
    private val faceDetector = FaceDetection.getClient(
        FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).build()
    )
    private var frameCount = 0
    @Volatile private var busy = false

    fun analyze(image: ImageProxy) {
        frameCount++
        if (busy || frameCount % 4 != 0) { image.close(); return }
        val mediaImage = image.image
        if (mediaImage == null) { image.close(); return }
        busy = true
        val rotation = image.imageInfo.rotationDegrees
        val input = InputImage.fromMediaImage(mediaImage, rotation)
        val iw: Int; val ih: Int
        if (rotation == 90 || rotation == 270) { iw = mediaImage.height; ih = mediaImage.width }
        else { iw = mediaImage.width; ih = mediaImage.height }

        var pending = 2
        val boxes = java.util.Collections.synchronizedList(ArrayList<DetBox>())
        fun done() {
            pending--
            if (pending == 0) { onBoxes(boxes.toList()); image.close(); busy = false }
        }

        objectDetector.process(input)
            .addOnSuccessListener { objs ->
                for (o in objs) {
                    val b = o.boundingBox
                    val label = arabicLabel(o.labels.firstOrNull()?.text)
                    boxes.add(DetBox(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(), label, iw, ih))
                }
            }
            .addOnCompleteListener { done() }

        faceDetector.process(input)
            .addOnSuccessListener { faces ->
                for (fc in faces) {
                    val b = fc.boundingBox
                    boxes.add(DetBox(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(), "شخص", iw, ih))
                }
            }
            .addOnCompleteListener { done() }
    }

    fun close() {
        try { objectDetector.close() } catch (e: Throwable) { }
        try { faceDetector.close() } catch (e: Throwable) { }
    }
}
