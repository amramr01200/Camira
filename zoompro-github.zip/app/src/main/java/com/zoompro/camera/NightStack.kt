package com.zoompro.camera

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * يدمج عدة لقطات ليلية بتقنيتين حقيقيتين (وليستا مجرد تفتيح الصورة):
 * 1) دمج مُشذَّب (Trimmed-Mean): يُسقط أعلى وأدنى قيمة لكل بكسل قبل حساب المتوسط،
 *    فيقلّل الضوضاء العشوائية و"الأشباح" الناتجة عن حركة طفيفة في اليد أكثر من
 *    المتوسط البسيط. يُفعَّل تلقائياً عند وجود 5 لقطات فأكثر.
 * 2) تنقية الضوضاء اللونية (Chroma Denoising): الضوضاء في الإضاءة المنخفضة تظهر
 *    أساساً كبقع لونية عشوائية. نُنعّم القناتين اللونيتين (Cb/Cr) مع الحفاظ على
 *    تفاصيل الإضاءة (Y) حادة، فتقل الحبيبية الملوّنة دون تمييع التفاصيل.
 * هذه تقنيات معالجة إشارة حقيقية ومُثبتة الفعالية، وليست نموذج ذكاء اصطناعي
 * مُدرَّب (أمانة: لا تتوفر هنا بيئة لتدريب/التحقق من نموذج كهذا بثقة).
 */
class NightStacker(private val longSide: Int = 1600) {
    private var w = 0
    private var h = 0
    private val framesR = ArrayList<ByteArray>()
    private val framesG = ArrayList<ByteArray>()
    private val framesB = ArrayList<ByteArray>()

    fun add(upright: Bitmap) {
        if (w == 0) {
            val s = longSide.toFloat() / max(upright.width, upright.height)
            w = (upright.width * s).roundToInt().coerceAtLeast(1)
            h = (upright.height * s).roundToInt().coerceAtLeast(1)
        }
        val scaled = Bitmap.createScaledBitmap(upright, w, h, true)
        val px = IntArray(w * h)
        scaled.getPixels(px, 0, w, 0, 0, w, h)
        if (scaled !== upright) scaled.recycle()
        val r = ByteArray(w * h); val g = ByteArray(w * h); val b = ByteArray(w * h)
        for (i in px.indices) {
            val p = px[i]
            r[i] = ((p shr 16) and 255).toByte()
            g[i] = ((p shr 8) and 255).toByte()
            b[i] = (p and 255).toByte()
        }
        framesR.add(r); framesG.add(g); framesB.add(b)
    }

    private fun combine(frames: List<ByteArray>, i: Int): Int {
        val n = frames.size
        if (n <= 4) {
            var s = 0
            for (k in 0 until n) s += frames[k][i].toInt() and 255
            return s / n
        }
        var sum = 0; var mn = 256; var mx = -1
        for (k in 0 until n) {
            val v = frames[k][i].toInt() and 255
            sum += v
            if (v < mn) mn = v
            if (v > mx) mx = v
        }
        return (sum - mn - mx) / (n - 2)
    }

    fun result(gamma: Float = 0.62f): Bitmap {
        val n = framesR.size
        if (n == 0) error("لا توجد لقطات لدمجها")
        val lut = IntArray(256) { (255.0 * (it / 255.0).pow(gamma.toDouble())).roundToInt().coerceIn(0, 255) }
        val out = IntArray(w * h)
        for (i in 0 until w * h) {
            val rr = lut[combine(framesR, i)]
            val gg = lut[combine(framesG, i)]
            val bb = lut[combine(framesB, i)]
            out[i] = (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
        }
        return denoiseChroma(Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888))
    }
}

/** تنعيم القناتين اللونيتين (Cb/Cr) بمتوسط 3×3 مع إبقاء الإضاءة (Y) حادة كما هي. */
private fun denoiseChroma(src: Bitmap): Bitmap {
    val w = src.width; val h = src.height
    val px = IntArray(w * h)
    src.getPixels(px, 0, w, 0, 0, w, h)
    val cb = FloatArray(w * h); val cr = FloatArray(w * h)
    for (i in px.indices) {
        val p = px[i]
        val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
        cb[i] = -0.169f * r - 0.331f * g + 0.5f * b
        cr[i] = 0.5f * r - 0.419f * g - 0.081f * b
    }
    val out = IntArray(w * h)
    for (y in 0 until h) {
        for (x in 0 until w) {
            val i = y * w + x
            var sb = 0f; var sr = 0f; var c = 0
            for (dy in -1..1) {
                val yy = (y + dy).coerceIn(0, h - 1)
                for (dx in -1..1) {
                    val xx = (x + dx).coerceIn(0, w - 1)
                    val j = yy * w + xx
                    sb += cb[j]; sr += cr[j]; c++
                }
            }
            val bAvg = sb / c; val rAvg = sr / c
            val p = px[i]
            val rO = (p shr 16) and 255; val gO = (p shr 8) and 255; val bO = p and 255
            val y0 = 0.299f * rO + 0.587f * gO + 0.114f * bO
            val r2 = (y0 + 1.402f * rAvg).roundToInt().coerceIn(0, 255)
            val g2 = (y0 - 0.344f * bAvg - 0.714f * rAvg).roundToInt().coerceIn(0, 255)
            val b2 = (y0 + 1.772f * bAvg).roundToInt().coerceIn(0, 255)
            out[i] = (0xFF shl 24) or (r2 shl 16) or (g2 shl 8) or b2
        }
    }
    src.recycle()
    return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
}
