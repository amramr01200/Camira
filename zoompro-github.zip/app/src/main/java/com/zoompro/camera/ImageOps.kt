package com.zoompro.camera

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** حدة خفيفة (Unsharp Mask بمرشح 3x3) لتحسين الصورة المكبّرة برمجياً. */
fun sharpen(src: Bitmap, amount: Float): Bitmap {
    val w = src.width
    val h = src.height
    val px = IntArray(w * h)
    src.getPixels(px, 0, w, 0, 0, w, h)
    val out = px.copyOf()
    for (y in 1 until h - 1) {
        val row = y * w
        for (x in 1 until w - 1) {
            val i = row + x
            var sr = 0; var sg = 0; var sb = 0
            for (dy in -1..1) {
                for (dx in -1..1) {
                    val p = px[i + dy * w + dx]
                    sr += (p shr 16) and 255
                    sg += (p shr 8) and 255
                    sb += p and 255
                }
            }
            val c = px[i]
            val cr = (c shr 16) and 255
            val cg = (c shr 8) and 255
            val cb = c and 255
            // شحذ تكيّفي: لا نضخّم الفروق الصغيرة (الضوضاء)، ونحدّ التفاف الحواف
            val dr = cr - sr / 9f
            val dg = cg - sg / 9f
            val db = cb - sb / 9f
            val nr = (if (abs(dr) > 3f) cr + amount * dr.coerceIn(-40f, 40f) else cr.toFloat()).toInt().coerceIn(0, 255)
            val ng = (if (abs(dg) > 3f) cg + amount * dg.coerceIn(-40f, 40f) else cg.toFloat()).toInt().coerceIn(0, 255)
            val nb = (if (abs(db) > 3f) cb + amount * db.coerceIn(-40f, 40f) else cb.toFloat()).toInt().coerceIn(0, 255)
            out[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
        }
    }
    return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
}

/**
 * تكبير برمجي فوق حد عدسة الهاتف: قص المركز ثم رفع الحجم ثم شحذ.
 * soft = نسبة التكبير الزائدة (zoom / أقصى زوم للعتاد). يعيد src نفسه إن لم يلزم.
 */
fun boostZoom(src: Bitmap, soft: Float): Bitmap {
    if (soft <= 1.01f) return src
    val w2 = (src.width / soft).toInt().coerceAtLeast(16)
    val h2 = (src.height / soft).toInt().coerceAtLeast(16)
    val x = (src.width - w2) / 2
    val y = (src.height - h2) / 2
    val cropped = Bitmap.createBitmap(src, x, y, w2, h2)
    val k = min(1f, 3000f / max(src.width, src.height))
    val tw = (src.width * k).toInt()
    val th = (src.height * k).toInt()
    // رفع تدريجي بخطوات 1.5x (أنعم من قفزة واحدة)
    var cur = cropped
    while (cur.width * 1.5f < tw) {
        val next = Bitmap.createScaledBitmap(cur, (cur.width * 1.5f).toInt(), (cur.height * 1.5f).toInt(), true)
        if (cur !== src) cur.recycle()
        cur = next
    }
    val scaled = Bitmap.createScaledBitmap(cur, tw, th, true)
    if (cur !== scaled && cur !== src) cur.recycle()
    val out = sharpen(scaled, (0.5f + 0.12f * (soft - 1f)).coerceAtMost(1.1f))
    scaled.recycle()
    return out
}
